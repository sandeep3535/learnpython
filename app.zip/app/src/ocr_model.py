from paddleocr import PaddleOCR


class OCRModel:
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls._create_instance()
        return cls._instance

    @classmethod
    def _create_instance(cls):
        ocr = PaddleOCR(use_angle_cls=True, lang='en')
        return ocr
