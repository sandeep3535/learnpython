from fastapi import Request


def getSession(collection_name: str):
    def _getSession(request: Request):
        yield request.app.mongodb[collection_name]
    return _getSession


