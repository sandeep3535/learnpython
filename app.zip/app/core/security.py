from passlib.context import CryptContext


class Hash:
    def __init__(self):
        self.context = CryptContext(schemes=['bcrypt'])

    async def bcrypt(self, password):
        return self.context.hash(secret=password)

    async def bcrypt_verify(self, password: str, user_password: str):
        return self.context.verify(secret=password, hash=user_password)
