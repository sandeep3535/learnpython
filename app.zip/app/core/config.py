import os
from dotenv import load_dotenv
# from pydantic import BaseSettings
from pydantic_settings import BaseSettings
from typing import ClassVar


class CommonSettings(BaseSettings):
    APP_NAME: str = "Eat"
    APP_DESCRIPTION: str = "Eat- Eating All Togather"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False


class ServerSettings(BaseSettings):
    HOST: str = "127.0.0.1"
    PORT: int = 8005


class DatabaseSettings(BaseSettings):
    load_dotenv()
    DATABASE_URL: str = os.getenv("MONGO_DB_URI")
    DATABASE_NAME: str = os.getenv("MONGO_DB_NAME")


class Settings(CommonSettings, ServerSettings, DatabaseSettings):
    pass


settings = Settings()
