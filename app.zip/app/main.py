import asyncio
import time

from async_timeout import timeout
from fastapi import FastAPI, Depends, Header, HTTPException, Request
from fastapi.datastructures import UploadFile
from motor.motor_asyncio import AsyncIOMotorClient
from app.db.database import getSession
from app.core import settings
from app.models.refine_recommendation import RecipeRecommendationModel
from app.models.wine_recommendation import WineRecommendationModel
from app.models.cocktail_recommendation import CocktailRecommendationModel
from app.models.foodpair import Winefoodsuggetion
from app.models.winepair import Foodwinesuggetion
from app.models.recipe_vision import RecipeVision
from app.models.cocktails_ocr import CocktailOcrResult
from app.models.food_cocktails import Foodcocktail
from app.models.wine_ocr import WineOcrResult
from app.models.winelist_ocr import WineListOcrResult
from app.models.nutrition_ocr_II import NutritionOcr
from app.models.similar_cocktail import SimilarCocktail
from app.models.similar_wine import Similarwine
from app.models.cocktail_food import Cocktailfood
from app.schemas.reciperecommendation_schema import RecipeRecommendationSchemas
from app.schemas.winerecommendation_schema import WineRecommendationSchema
from app.schemas.cocktailrecommendation_schema import CocktailRecommendationSchema
from app.schemas.foodpair_schema import FoodpairSchema
from app.schemas.winepair_schema import WinepairSchema
from app.schemas.recipevision_schema import RecipeVisionSchema
from app.schemas.cocktailocr_schema import CocktailOcrSchema
from app.schemas.cocktailrecipe_schema import CocktailRecipeSchema
from app.schemas.wineocr_schema import WineOcrSchema
from app.schemas.nutritionocr_schema import NutritionOcr_schema
from app.schemas.similarcocktail_schema import SimilarCocktailSchema
from app.schemas.similarwine_schema import SimilarWineSchema
from app.schemas.cocktailfood_schema import CocktailfoodSchema
from app.schemas.foodcocktail_schema import FoodcocktailSchema
import nltk

app = FastAPI(title=settings.APP_NAME, description=settings.APP_DESCRIPTION, version=settings.APP_VERSION)

nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

recipe_model = RecipeRecommendationModel()
wine_model = WineRecommendationModel()
cocktail_model = CocktailRecommendationModel()
foodpair_model = Winefoodsuggetion()
winepair_model = Foodwinesuggetion()
cocktailfood_model = Cocktailfood()
foodcocktail_model = Foodcocktail()
recipe_vision_model = RecipeVision()
cocktailocr_model = CocktailOcrResult()
wineocr_model = WineOcrResult()
winelistocr_model = WineListOcrResult()
nutritionocr_model = NutritionOcr()
similarcocktail_model = SimilarCocktail()
similarwine_model = Similarwine()


@app.on_event("startup")
async def startup():
    # Create database tables

    app.mongo_client = AsyncIOMotorClient(settings.DATABASE_URL)
    app.mongodb = app.mongo_client[settings.DATABASE_NAME]
    recipe_collection = app.mongodb['recipe_data']
    wine_collection = app.mongodb['wine_vivino_data']
    cocktail_collection = app.mongodb['cocktail_data']
    await recipe_model.load_and_preprocess_data(recipe_collection)
    await wine_model.load_and_preprocess_data(wine_collection)
    await cocktail_model.load_and_preprocess_data(cocktail_collection)
    await foodpair_model.load_and_preprocess_data(recipe_collection, wine_collection)
    await winepair_model.load_and_preprocess_data(recipe_collection, wine_collection)
    await cocktailfood_model.load_and_preprocess_data(recipe_collection, cocktail_collection)
    await foodcocktail_model.load_and_preprocess_data(recipe_collection, cocktail_collection)
    await recipe_vision_model.load_and_preprocess_data(recipe_collection)
    await cocktailocr_model.load_and_preprocess_data(cocktail_collection)
    await wineocr_model.load_and_preprocess_data(wine_collection)
    await winelistocr_model.load_and_preprocess_data(wine_collection)
    await similarcocktail_model.load_and_preprocess_data(cocktail_collection)
    await nutritionocr_model.load_model()
    await similarwine_model.load_and_preprocess_data(wine_collection)


@app.post("/foodrecommendations")
async def get_food_recommendation(request: RecipeRecommendationSchemas, favourite=Depends(getSession('favourite')),
                                  recipe=Depends(getSession('recipes'))):
    request_dict = request.dict()
    user_id = request_dict['user_id']
    n = request_dict['n']
    recommendations = await recipe_model.get_recommendations(favourite, recipe, user_id, n)
    return {"foodrecommendations": recommendations}


@app.post("/winerecommendation")
async def get_wine_recommendation(request: WineRecommendationSchema, favourite=Depends(getSession('favourite'))):
    request_dict = request.dict()
    user_id = request_dict['user_id']
    n = request_dict['n']
    recommendations = await wine_model.get_wine_recommendations(favourite, user_id, n)
    return {"wine_recommendation": recommendations}


#
#
@app.post("/cocktailrecommendation")
async def get_cocktail_recommendation(request: CocktailRecommendationSchema,
                                      favourite=Depends(getSession('favourite'))):
    request_dict = request.dict()
    user_id = request_dict['user_id']
    n = request_dict['n']
    recommendations = await cocktail_model.get_recommend_cocktails(favourite, user_id, n)
    return {"cocktail_recommendation": recommendations}


@app.post("/foodpair")
async def get_foodpair(request: FoodpairSchema):
    request_dict = request.dict()
    wine_id = request_dict['wine_id']
    n = request_dict['n']
    foodpair = await foodpair_model.get_foodpair(wine_id, n)
    return {"foodpair": foodpair}


@app.post("/winepair")
async def get_winepair(request: WinepairSchema):
    request_dict = request.dict()
    recipe_id = request_dict['recipe_id']
    n = request_dict['n']
    winepair = await winepair_model.get_winepair(recipe_id, n)
    return {"winepair": winepair}


@app.post("/cocktailfoodpair")
async def get_cocktail_foodpair(request: CocktailfoodSchema):
    request_dict = request.dict()
    cocktail_id = request_dict['cocktail_id']
    n = request_dict['n']
    cocktailfoodpair = await cocktailfood_model.get_cocktail_foodpair(cocktail_id, n)
    return {"cocktailfoodpair": cocktailfoodpair}


@app.post("/foodcocktailpair")
async def get_food_cocktailpair(request: FoodcocktailSchema):
    request_dict = request.dict()
    recipe_id = request_dict['recipe_id']
    n = request_dict['n']
    foodcocktailpair = await foodcocktail_model.get_food_cocktailpair(recipe_id, n)
    return {"foodcocktailpair": foodcocktailpair}


@app.post("/recipe-vision")
async def get_recipe_vision(request: RecipeVisionSchema):
    dict_recipe = request.dict()
    if 'recipe' in dict_recipe and dict_recipe['recipe'] is not None:
        recipe_det_result = await recipe_vision_model.get_ocr_recipe(dict_recipe)
    else:
        recipe_det_result = await recipe_vision_model.get_ocr_recipe(dict_recipe)
    return {"suggested_recipe": recipe_det_result}


@app.post('/image-recipe-list')
async def recipe_image_ocr_data(ingradients: str = None, search: str = None, image: UploadFile = None,
                                token: str = Header(None), image_url: str= None,type: str = None, item_per_page: int = 5,
                                current_page: int = 1, favourite=Depends(getSession('favourite')),
                                customer=Depends(getSession('customers')), archive=Depends(getSession('archive')),
                                allergie=Depends(getSession('allergies')),recipes_collection = Depends(getSession('recipe_data')),gallery_collection=Depends(getSession('gallery'))):
    recipe_data = {
        'type': type,
        'image': image,
        'image_url':image_url,
        # 'calorie_from': calorie_from,
        # 'calorie_to': calorie_to,
        # 'total_time_from': total_time_from,
        # 'total_time_to': total_time_to,
        # 'category': category,
        # 'fav': fav,
        'item_per_page': item_per_page,
        'current_page': current_page,
        'token': token,
        'search': search,
        'ingradients': ingradients
    }
    recipe_detail = await recipe_vision_model.get_recipe_ocr_data(recipe_data, fav_collection=favourite,
                                                                  customers_collection=customer,
                                                                  allergies_collection=allergie,
                                                                  archived_collection=archive,
                                                                  recipes_collection=recipes_collection,gallery_collection=gallery_collection)
    return recipe_detail


@app.post("/cocktail-ocr/")
async def get_cocktail_ocr(request: CocktailOcrSchema):
    dict_cocktail = request.dict()
    if 'cocktail' in dict_cocktail and dict_cocktail['cocktail'] is not None:
        cocktail_ocr_result = await cocktailocr_model.get_cocktail(dict_cocktail)
    else:
        cocktail_ocr_result = await cocktailocr_model.get_cocktail(dict_cocktail)

    return {"suggested_cocktail": cocktail_ocr_result}


@app.post('/cocktail-image-ingradients-list')
async def get_cocktail_recipe(ingradients: str = None, search: str = None,image_url: str = None,
                              image: UploadFile = None,
                              token: str = Header(None), item_per_page: int = 5, current_page: int = 1,
                              favourite=Depends(getSession('favourite')), customer=Depends(getSession('customers')),
                              archive=Depends(getSession('archive')),gallery=Depends(getSession("gallery"))):
    cocktail_data = {
        'image': image,
        'image_url': image_url,
        'item_per_page': item_per_page,
        'current_page': current_page,
        'token': token,
        'search': search,
        'ingradients': ingradients
    }
    cocktail_recipe_detail = await cocktailocr_model.get_cocktail_ocr_data(cocktail_data, customers_collection=customer,
                                                                           favourite_collection=favourite,
                                                                           archived_collection=archive,gallery_collection=gallery)
    return cocktail_recipe_detail


@app.post("/wineocr/")
async def get_wineocr(request: WineOcrSchema):
    start_time = time.time()
    dict_wine = request.dict()
    if dict_wine['type'] == "list":
        wine_ocr_result = await winelistocr_model.get_winelist(dict_wine)
    elif dict_wine['type'] == "label":
        wine_ocr_result = await wineocr_model.get_wine(dict_wine)
    else:
        wine_ocr_result = await wineocr_model.get_wine(dict_wine)
    # wine_ocr_result = await wine_ocr.get_wine(dict_wine)
    print("Total_runnig_time:", time.time() - start_time)
    return {"suggested_wine": wine_ocr_result}


@app.post("/nutrition-ocr/")
async def get_nutrition_ocr(request: NutritionOcr_schema):
    dict_nutrition = request.dict()
    # dict_nutrition = request.dict()
    # print(dict_nutrition)
    nutritions_ocr_result = await nutritionocr_model.formate_nutrition(dict_nutrition)
    return {"suggested_nutritions": nutritions_ocr_result}


@app.post('/nutrition-ocr-list')
async def nutrition_ocr_list(image: UploadFile = None,
                             token: str = Header(None), customer=Depends(getSession('customers'))):
    nutrition_data = {
        'image': image,
        'token': token,
    }

    nutrition_recipe_detail = await nutritionocr_model.get_nutrition_ocr_data(nutrition_data,
                                                                              customers_collection=customer)
    return nutrition_recipe_detail


@app.post("/similar_cocktail")
async def get_similar_cocktail(request: SimilarCocktailSchema):
    request_dict = request.dict()
    recipe_id = request_dict['cocktail_id']
    n = request_dict['n']
    similarcocktail = await similarcocktail_model.get_similar_cocktails(recipe_id, n)
    return {"similar_cocktails": similarcocktail}


@app.post("/similar_wine")
async def get_similar_wine(request: SimilarWineSchema):
    request_dict = request.dict()
    wine_id = request_dict['wine_id']
    n = request_dict['n']
    similarwine = await similarwine_model.get_similar_wine(wine_id, n)
    return {"similar_wine": similarwine}


async def getMessage(constant: str):
    lang_msg = getSession("language_messages")
    message = await lang_msg.find({"constant": constant})
    return message

# @app.on_event("shutdown")
# async def shutdown():
#     # Close database connection
#     app.mongo_client.close()
