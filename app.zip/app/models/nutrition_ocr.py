# !/usr/bin/env python
# coding: utf-8
import time
import os
import boto3
# In[9]:
from ultralytics import YOLO
from deskew import determine_skew
from thefuzz import process, fuzz
from PIL import Image
import cv2
import asyncio
import re
import math
from paddleocr import PaddleOCR
import numpy as np
import logging
from motor.motor_asyncio import AsyncIOMotorClient
from app.src.ocr_model import ocr
from PIL import Image
import requests


class NutritionOcr:
    def __init__(self):
        self._names = ['total fat', 'saturated fat', 'trans fat', 'cholesterol', 'sodium', 'total carbohydrate',
                       'fibre', 'total sugars', 'protein', 'vitamin d', 'calcium', 'iron', 'potassium']
        self.Nutrition = {}
        # self.nutrition_collection = self.db['micro_nutritions']
        # self.customers_collection = self.db['customers']
        # self.ocr = None
        self.model = None
        self.logger = logging.getLogger(__name__)

    async def load_model(self):
        try:
            # self.ocr = PaddleOCR(use_angle_cls=True, lang='en', image_orientation=True)
            self.model = YOLO('/home/coreutils-21/Documents/EAT/app/models/table_det.pt')
            self.logger.info("Models loaded successfully")
        except Exception as e:
            self.logger.error(f"An error occurred while loading models: {e}")

    async def deskew_image(self, image):
        try:
            old_width, old_height = image.shape[:2]
            angle = determine_skew(image)
            if angle:
                angle_radian = math.radians(angle)
                width = abs(np.sin(angle_radian) * old_height) + abs(np.cos(angle_radian) * old_width)
                height = abs(np.sin(angle_radian) * old_width) + abs(np.cos(angle_radian) * old_height)
                image_center = tuple(np.array(image.shape[1::-1]) / 2)
                rot_mat = cv2.getRotationMatrix2D(image_center, angle, 1.0)
                rot_mat[1, 2] += (width - old_width) / 2
                rot_mat[0, 2] += (height - old_height) / 2
                return cv2.warpAffine(image, rot_mat, (int(round(height)), int(round(width))), borderValue=(0, 0, 0))
            else:
                return image
        except Exception as e:
            self.logger.error(f"An error occurred while de-skewing image: {e}")
            return []

    async def noise_removal(self, image):
        try:
            return cv2.fastNlMeansDenoisingColored(image, None, 10, 10, 7, 15)
        except Exception as e:
            self.logger.error(f"An error occurred while removing noise from image: {e}")
            return []

    async def crop_image(self, image_link):
        try:
            det_result = self.model(image_link)
            box = []
            orig_img = []
            for r in det_result:
                box = r.boxes.xyxy.numpy().astype('int')
                orig_img = r.orig_img
            if len(box) > 0:
                img = orig_img[box[0][1]:box[0][3], box[0][0]:box[0][2]]
                return img
            else:
                return orig_img
        except Exception as e:
            self.logger.error(f"An error occurred while cropping image: {e}")
            return []

    async def rotate_image(self, image):
        try:
            # Convert to grayscale
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            # Find contours
            contours, _ = cv2.findContours(gray, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            if contours:
                # Approximate the contour
                epsilon = 0.04 * cv2.arcLength(contours[0], True)
                approx = cv2.approxPolyDP(contours[0], epsilon, True)

                # Calculate the minimum area rectangle
                rect = cv2.minAreaRect(approx)

                # Extract angle from the rotated rectangle
                angle = rect[-1]
                pil_image = Image.fromarray(image)
                rotated_image = pil_image.rotate(-angle, resample=Image.BICUBIC, expand=True)
                rotated_image_array = np.array(rotated_image)

                return rotated_image_array[:, :, ::-1]  # Convert RGB to BGR
        except Exception as e:
            self.logger.error(f"An error occurred while rotating image: {e}")
            return []

    async def preprocess_image(self, image_link):
        try:
            if requests.get(image_link).status_code == 200:
                image = Image.open(requests.get(image_link, stream=True).raw)
                image = await self.crop_image(image)
                # rotate_img = await self.rotate_image(image)
                dnsy_img = await self.noise_removal(image)
                deskew_img = await self.deskew_image(dnsy_img)
                path = os.path.join(os.getcwd(), "app/models/", image_link.split("/")[-1])
                if os.path.exists(path):
                    os.remove(path)
                return deskew_img
            else:
                return []
        except Exception as e:
            self.logger.error(f"An error occurred while preprocessing image: {e}")
            return []

    async def get_centroid_y(self, b_box):
        try:
            centroid_x = sum(x for x, _ in b_box) / len(b_box)
            centroid_y = sum(y for _, y in b_box) / len(b_box)
            return centroid_x, centroid_y
        except Exception as e:
            self.logger.error(f"An error occurred while getting centroid of y: {e}")
            return []

    async def get_ocrtext(self, image):
        try:
            ocr_result = ocr.ocr(image, cls=True)
            ocr_text_with_bbox = []
            for idx in range(len(ocr_result)):
                res = ocr_result[idx]
                for line in res:
                    ocr_text_with_bbox.append((await self.get_centroid_y(b_box=line[0]), line[-1][0]))
            sorted_ocr_text_with_bbox = sorted(ocr_text_with_bbox, key=lambda x: (x[0][1]))
            ocr_text = [text[1].lower() for text in sorted_ocr_text_with_bbox]
            return ocr_text
        except Exception as e:
            self.logger.error(f"An error occurred while getting ocr text: {e}")
            return []

    async def get_calories(self, ocr_text):
        try:
            for idx, txt in enumerate(ocr_text):
                cal_similarity = fuzz.ratio("calories", txt)
                pattern = r'\b(\d+)\s*(?:calories?)?\b'
                if cal_similarity > 80 and re.findall(pattern, txt, re.IGNORECASE):
                    return re.findall(pattern, txt, re.IGNORECASE)[0]
                elif cal_similarity > 80 and idx == 0:
                    if ocr_text[idx + 1].isdigit():
                        return ocr_text[idx + 1]
                elif cal_similarity > 80 and idx == (len(ocr_text) - 1):
                    if ocr_text[idx - 1].isdigit():
                        return ocr_text[idx - 1]
                elif cal_similarity > 80:
                    if ocr_text[idx - 1].isdigit():
                        return ocr_text[idx - 1]
                    elif ocr_text[idx + 1].isdigit():
                        return ocr_text[idx + 1]
            return ""
        except Exception as e:
            self.logger.error(f"An error occurred while getting calories: {e}")
            return ""

    async def get_serving_size(self, ocr_text):
        try:
            for idx, text in enumerate(ocr_text):
                similarity = fuzz.ratio("serving size", text)
                if similarity >= 80:
                    pattern = r'(\d+(\.\d+)?/\d+(\.\d+)?|\d+(\.\d+)?)(?:\s*\w+)(?:\s*\(\d+(\.\d+)?g\))?(?:\.\d+g)?'
                    if idx == 0 and re.search(pattern, ocr_text[idx + 1], re.IGNORECASE):
                        return ocr_text[idx + 1]
                    elif idx == (len(ocr_text) - 1) and re.search(pattern, ocr_text[idx - 1], re.IGNORECASE):
                        return ocr_text[idx - 1]
                    else:
                        if re.search(pattern, ocr_text[idx - 1], re.IGNORECASE):
                            return ocr_text[idx - 1]
                        elif re.search(pattern, ocr_text[idx + 1], re.IGNORECASE):
                            return ocr_text[idx + 1]
            return ""
        except Exception as e:
            self.logger.error(f"An error occurred while getting serving size: {e}")
            return ""

    async def get_label_from_string(self, string):
        try:
            label_arr = re.findall("([A-Z][a-zA-Z]*)", string)
            label_name = ""
            label_value = ""

            if len(label_arr) == 0:
                label_name = "|" + string + '|'
            elif len(label_arr) == 1:
                label_name = label_arr[0]
            else:
                label_name = label_arr[0] + ' ' + label_arr[1]

            digit_pattern = "[-+]?\d*\.\d+g|\d+"
            value_arr = re.findall("{0}g|{0}%|{0}J|{0}kJ|{0}mg|{0}mcg|{0}kcal".format(digit_pattern), string)
            if len(value_arr):
                label_value = value_arr[0]
            else:
                label_value = "0"
            return re.sub(r'(?<!\d)\.(?=\d)', '', label_value)
        except Exception as e:
            self.logger.error(f"An error occurred while getting label from string: {e}")
            return ""

    async def change_to_g(self, text):
        try:
            search_ln = re.search("\d\s|\d$", text)
            if search_ln and search_ln.group().strip() == "9":
                index = search_ln.span()[0]
                text = text[:index] + "g" + text[index + 1:]

            search_lnq = re.search("\dmq\s|\dmq$", text)
            if search_lnq:
                index = search_lnq.span()[0] + 2
                text = text[:index] + "g" + text[index + 1:]
            return text
        except Exception as e:
            self.logger.error(f"An error occurred while changing to g {e}")
            return ""

    async def clean_string(self, string):
        try:
            pattern = "[\|\*\_\'\—\-\{}]".format('"')
            text = re.sub(pattern, "", string)
            text = re.sub(" I ", " / ", text)
            text = re.sub("^I ", "", text)
            text = re.sub("Omg|omg", "0mg", text)
            text = re.sub("Omcg|omcg", "0mcg", text)
            text = re.sub("Og|og", "0g", text)
            text = re.sub('(?<=\d) (?=\w)', '', text)
            text = await self.change_to_g(text)
            text = text.strip()
            return text
        except Exception as e:
            self.logger.error(f"An error occurred while cleaning string {e}")
            return ""

    async def get_all_nutrition(self, image):
        try:
            pre_image = await self.preprocess_image(image)
            ocr_text = await self.get_ocrtext(image=pre_image)

            exclude_list = ['Nutrition Facts.', 'Servings Per Container', 'Amount Per Serving', 'Includes Added Sugars']
            if ocr_text:
                for data in self._names:
                    matched_list = process.extract(data, ocr_text, scorer=fuzz.ratio)
                    if int(matched_list[0][1]) > 40:
                        _fnl = await self.clean_string(matched_list[0][0])
                        self.Nutrition[data] = await self.get_label_from_string(_fnl)
                    else:
                        self.Nutrition[data] = "0"
                for data in exclude_list:
                    matched_list = process.extract(data, ocr_text, scorer=fuzz.ratio)
                    if int(matched_list[0][1]) > 60:
                        ocr_text.remove(matched_list[0][0])
                calorie = await self.get_calories(ocr_text)
                serving = await self.get_serving_size(ocr_text)
                # self.Nutrition['calories'] = calorie + " cals" if calorie else "0 cals"
                self.Nutrition['calories'] = calorie if calorie else "0"
                self.Nutrition['serving size'] = serving if serving else "0"
                return self.Nutrition
            else:
                # for data in self._names:
                #     self.Nutrition[data] = "0"
                # self.Nutrition['calories'] = "0 cals"
                # self.Nutrition['serving size'] = "0"
                # return self.Nutrition
                return self.Nutrition

        except Exception as e:
            self.logger.error(f"An error occurred while getting all nutrition details: {e}")
            return {}

    async def formate_nutrition(self, img_lnk: dict):
        try:
            nutrition = await self.get_all_nutrition(img_lnk['nutrition'])
            if any(num != "0" for num in nutrition.values()):
                output_dict = {
                    'nutrition': {
                        'calories': nutrition['calories'] + ' cals',
                        'protein': nutrition['protein'],
                        'carbs': nutrition['total carbohydrate'],
                        'fat': nutrition['total fat']
                    },
                    'micro-nutrition': {
                        key: value for key, value in nutrition.items()
                        if key not in ('calories', 'protein', 'total carbohydrate', 'total fat', 'serving size')
                    },

                    'serving size': nutrition['serving size']
                }

                return output_dict

            else:
                return {}
        except Exception as e:
            self.logger.error(f"An error occurred while formatting nutrition: {e}")
            return {}

    async def get_nutrition_ocr_data(self, nutrition_req, customers_collection):
        global nutrition_ocr_data, data
        image = nutrition_req['image']
        users = await customers_collection.find_one({"verify_token": nutrition_req['token']})
        if users:
            if image is not None:
                s3 = boto3.client(
                    "s3",
                    aws_access_key_id="AKIAYLJH7CDVSNC6YWV7",
                    aws_secret_access_key="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",
                    region_name="ap-south-1"
                )
                # ingrediant_file = f"wine/{user_id}/{str(int(time.time()))}.{image.filename.split('.')[-1]}"
                ingradient_file = "nutritions/" + str(users['_id']) + "/" + str(int(time.time())) + "." + \
                                  image.filename.split('.')[-1]

                s3.upload_fileobj(image.file, "coretus-development", ingradient_file, ExtraArgs={'ACL': 'public-read'})
                ing_image = "https://coretus-development.s3.ap-south-1.amazonaws.com/" + ingradient_file
                nutrition_ocr_data = await self.formate_nutrition({"nutrition": ing_image})

                if 'suggested_nutritions' in nutrition_ocr_data and nutrition_ocr_data is not None:
                    suggest_nutrition = {
                        "nutritions": nutrition_ocr_data['suggested_nutritions']['nutrition'],
                        "micro_nutritions": nutrition_ocr_data['suggested_nutritions'][
                            'micro-nutrition'],
                        "serving": nutrition_ocr_data['suggested_nutritions'][
                            'serving size']
                    }

                    data = {
                        'data': suggest_nutrition,
                        'status': True,
                        'message': "Nutrition List Gets Successfully"
                    }
                    return data
                else:

                    data = {
                        'data': [],
                        'status': True,
                        'message': "Nutrition List Not Found"
                    }
                    return data
            else:

                data = {
                    'data': [],
                    'status': True,
                    'message': "Nutrition List Not Found"
                }
                return data
        else:
            data = {
                'data': [],
                'status': True,
                'message': "You are not authorized to make the request. The authorization credentials provided for the request are invalid."
            }
            return data
        # print(cocktail_ocr_data)


# In[10]:


if __name__ == "__main__":
    async def main():
        mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                       "/?authSource=admin"

        ocr_model = NutritionOcr()
        await ocr_model.load_model()
        return await ocr_model.formate_nutrition({"nutrition": "http://localhost:8080/nutrition.jpg"})


    print(asyncio.run(main()))

# In[ ]:


# In[ ]:


# In[ ]:
