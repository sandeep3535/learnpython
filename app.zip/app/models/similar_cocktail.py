#!/usr/bin/env python
# coding: utf-8
import numpy
# In[9]:

import pandas as pd
import asyncio
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS
from sklearn.metrics.pairwise import cosine_similarity
from bson import ObjectId
import numpy as np
import logging
import motor.motor_asyncio
from unidecode import unidecode


class SimilarCocktail:
    def __init__(self):
        self.combine_vector = None
        self.cocktail_df = None
        self.vectorizer = None
        self.ing_vectors = None
        self.logger = logging.getLogger(__name__)

    async def preprocess_ingredients(self, ingredients: list) -> str:
        try:
            ingredient_list = []
            for ing in ingredients:
                ingredient_list.append(ing['ingredient'])

            return " ".join(ingredient_list)
        except Exception as e:
            self.logger.error(
                f"An error occurred while preprocess ingredients: {e} | Line: {e.__traceback__.tb_lineno}")
            return ""

    async def load_and_preprocess_data(self, cocktail_collection: motor.motor_asyncio.AsyncIOMotorCollection) -> None:
        try:
            data = await cocktail_collection.find().to_list(length=None)
            df = pd.DataFrame(data)
            cocktail_df = df.copy()

            cocktail_df['ingredients'] = await asyncio.gather(
                *(self.preprocess_ingredients(ing) for ing in cocktail_df['ingredients']))
            cocktail_df['cocktail_type'] = cocktail_df['cocktail_type'].apply(
                lambda cocktail_type: " ".join([unidecode(x.lower()) for x in cocktail_type]))
            cocktail_df['base_spirit'] = cocktail_df['base_spirit'].apply(
                lambda base_spirit: " ".join([unidecode(x.lower()) for x in base_spirit]))
            cocktail_df['glassware'] = cocktail_df['glassware'].apply(
                lambda glassware: " ".join([unidecode(x.lower()) for x in glassware]))

            cocktail_df['combine'] = cocktail_df['ingredients'] + " " + cocktail_df['cocktail_type'] + " " + \
                                     cocktail_df['base_spirit'] + " " + cocktail_df['glassware']

            self.vectorizer = TfidfVectorizer(stop_words=list(ENGLISH_STOP_WORDS))
            self.combine_vector = self.vectorizer.fit_transform(cocktail_df['combine'])

            self.cocktail_df = cocktail_df
            self.logger.info("Data loaded and preprocessed successfully")
        except Exception as e:
            self.logger.error(
                f"An error occurred while loading and preprocessing the data: {e} | Line: {e.__traceback__.tb_lineno}")

    async def word_to_vector(self, inputs: list) -> numpy.ndarray:
        try:
            inp_vector = self.vectorizer.transform(inputs)
            similarity = np.amax(cosine_similarity(inp_vector, self.combine_vector), axis=0)
            return similarity
        except Exception as e:
            self.logger.error(
                f"An error occurred while converting word to vector: {e} | Line: {e.__traceback__.tb_lineno}")
            return np.array([])

    async def get_similar_cocktails(self, cocktail_id: str, n: int) -> list:
        try:
            similar_id = self.cocktail_df[self.cocktail_df['_id'] == ObjectId(cocktail_id)][[
                'ingredients', 'cocktail_type', 'base_spirit', 'glassware']].values
            self.cocktail_df['score'] = await self.word_to_vector(inputs=similar_id[0])
            similar_ids = self.cocktail_df.sort_values('score', ascending=False)['_id'][1:n + 1]
            return [str(idx) for idx in similar_ids]
        except Exception as e:
            self.logger.error(
                f"An error occurred while getting similar cocktails: {e} | Line: {e.__traceback__.tb_lineno}")
            return []


# In[10]:


if __name__ == "__main__":
    from tqdm import tqdm


    async def fetch_data():
        mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                       "/?authSource=admin"
        from motor.motor_asyncio import AsyncIOMotorClient
        mongo_client = AsyncIOMotorClient(mongo_db_uri)
        mongo_db = mongo_client['Eat']
        cocktail_collection = mongo_db['cocktail_data']
        data = await cocktail_collection.find().to_list(length=None)
        cocktail_df = pd.DataFrame(data)
        ids = cocktail_df['_id'].astype('str').to_list()
        return ids, cocktail_collection


    async def main():
        data = await fetch_data()
        ids = data[0]
        recommendation_model = SimilarCocktail()
        await recommendation_model.load_and_preprocess_data(data[1])
        with tqdm(total=len(ids)) as pbar:
            for id in ids:
                similar_cocktails = await recommendation_model.get_similar_cocktails(id, 10)
                if len(similar_cocktails) < 10:
                    break
                pbar.update(1)


    asyncio.run(main())

# In[ ]:


# In[ ]:


# In[ ]:
