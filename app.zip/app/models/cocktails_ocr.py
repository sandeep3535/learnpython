#!/usr/bin/env python
# coding: utf-8
import time
from datetime import datetime
import boto3
import motor.motor_asyncio
import numpy
import pandas as pd
import asyncio
from nltk.stem import WordNetLemmatizer
import string
import re
from unidecode import unidecode
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from nltk.corpus import stopwords
import numpy as np
import logging
from app.src.ocr_model import OCRModel
import requests
import multiprocessing
import scipy


class CocktailOcrResult:
    def __init__(self):
        self.cocktail_df = None
        self.vectorizer = None
        self.combine_vectors = None
        self.ingredients_vector = None
        self.ingredients = []
        self.stopset = stopwords.words('english') + list(string.punctuation)
        self.wl = WordNetLemmatizer()
        self.logger = logging.getLogger(__name__)

    async def preprocess_ingredients(self, ingredients: list) -> list:
        try:
            ingredient_list = []
            for ing in ingredients:
                ingredient_list.append(ing['ingredient'])

            return ingredient_list
        except Exception as e:
            self.logger.error(
                f"An error occurred while preprocess ingredients: {e} | Line: {e.__traceback__.tb_lineno}")
            return []

    async def load_and_preprocess_data(self, cocktail_collection: motor.motor_asyncio.AsyncIOMotorCollection) -> None:
        try:
            data = await cocktail_collection.find().to_list(length=None)
            df = pd.DataFrame(data)
            cocktail_df = df.copy()

            cocktail_df['ingredients'] = await asyncio.gather(
                *(self.preprocess_ingredients(ing) for ing in cocktail_df['ingredients']))

            cocktail_df['join_ingredients'] = cocktail_df['ingredients'].apply(
                lambda ingredients: " ".join([unidecode(ing.lower()) for ing in ingredients]))

            self.vectorizer = TfidfVectorizer()
            self.combine_vectors = self.vectorizer.fit_transform(cocktail_df['join_ingredients'])
            self.cocktail_df = cocktail_df
            self.ingredients = list(set(
                unidecode(ingredient.lower()) for ing_list in self.cocktail_df['ingredients'] for ingredient in
                ing_list))
            self.ingredients_vector = self.vectorizer.fit_transform(self.ingredients)
            self.logger.info("Data loaded and preprocessed successfully")
        except Exception as e:
            self.logger.error(f"An error occurred while loading and preprocessing the data: {e}")

    async def word_to_vector(self, query: list, comp_corpus: scipy.sparse._csr.csr_matrix) -> numpy.ndarray:
        try:
            query_vectors = self.vectorizer.transform(query)
            similarity = cosine_similarity(query_vectors, comp_corpus)
            return similarity
        except Exception as e:
            self.logger.error(
                f"An error occurred while converting word to vector: {e} | Line: {e.__traceback__.tb_lineno}")
            return np.array([])

    def perform_ocr(self, image: str) -> list:
        try:
            ocr = OCRModel.get_instance()
            result = ocr.ocr(image, cls=True)
            return result
        except Exception as e:
            self.logger.error(f"An error occurred while perform ocr: {e} | Line: {e.__traceback__.tb_lineno}")
            return []

    async def get_ocrtext(self, image: str, timeout: int = 60) -> list:
        try:
            if requests.get(image).status_code == 200:
                with multiprocessing.Pool(processes=8) as pool:  # Adjust the number of processes as needed
                    result = pool.apply_async(self.perform_ocr, (image,))
                    try:
                        ocr_result = result.get(timeout=timeout)
                        ocr_text = [re.sub(r'[^a-zA-Z0-9\s]', '', line[-1][0].lower()).strip() for res in ocr_result for
                                    line in res]

                        return ocr_text
                    except multiprocessing.TimeoutError:
                        self.logger.error("OCR operation timed out.")
                        return []
            else:
                return []
        except Exception as e:
            self.logger.error(f"An error occurred while getting ocr text: {e} | Line: {e.__traceback__.tb_lineno}")
            return []

    async def get_cocktail(self, cocktail_ocr: dict) -> dict:
        try:
            if 'cocktail' in cocktail_ocr.keys() and cocktail_ocr['cocktail']:
                ocr_list = await self.get_ocrtext(cocktail_ocr['cocktail'])
                if ocr_list:
                    ocr_similarity = await self.word_to_vector(ocr_list, self.ingredients_vector)
                    similar_ingredients = [self.ingredients[np.argmax(arr)] for arr in ocr_similarity if
                                           max(arr) > 0.82]
                    if similar_ingredients:
                        ingredients_similarity = await self.word_to_vector([" ".join(similar_ingredients)],
                                                                           self.combine_vectors)
                        self.cocktail_df['score'] = ingredients_similarity[0]
                        return {"cocktail_id":
                                    self.cocktail_df.sort_values('score', ascending=False),
                                "ingredients": list(set(similar_ingredients))}
                    else:
                        return {}
                else:
                    return {}
            elif 'ingradient' in cocktail_ocr.keys() and cocktail_ocr['ingradient'] is not None:
                add_list = cocktail_ocr['ingradient'].split(",")
                if add_list:
                    add_similarity = await self.word_to_vector(add_list, self.ingredients_vector)
                    similar_ingredients = [self.ingredients[np.argmax(arr)] for arr in add_similarity if
                                           max(arr) > 0.82]
                    if similar_ingredients:
                        ingredients_similarity = await self.word_to_vector([" ".join(similar_ingredients)],
                                                                           self.combine_vectors)
                        self.cocktail_df['score'] = ingredients_similarity[0]
                        return {"cocktail_id":
                                    self.cocktail_df.sort_values('score', ascending=False),
                                "ingredients": list(set(similar_ingredients))}
                    else:
                        return {}
                else:
                    return {}
            else:
                return {}
        except Exception as e:
            self.logger.error(f"An error occurred while getting cocktails: {e} | Line: {e.__traceback__.tb_lineno}")
            return {}

    async def get_cocktail_ocr_data(self, cocktail_req, customers_collection, favourite_collection, archived_collection,
                                    gallery_collection) -> dict:
        try:
            image = cocktail_req['image']
            image_url = cocktail_req['image_url']
            users = await customers_collection.find_one({"verify_token": cocktail_req['token']})
            if users:
                if image is not None:
                    s3 = boto3.client(
                        "s3",
                        aws_access_key_id="AKIAYLJH7CDVSNC6YWV7",
                        aws_secret_access_key="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",
                        region_name="ap-south-1"
                    )
                    # ingrediant_file = f"wine/{user_id}/{str(int(time.time()))}.{image.filename.split('.')[-1]}"
                    ingradient_file = "cocktail/" + str(users['_id']) + "/" + str(int(time.time())) + "." + \
                                      image.filename.split('.')[-1]
                    s3.upload_fileobj(image.file, "coretus-development", ingradient_file,
                                      ExtraArgs={'ACL': 'public-read'})
                    ing_image = "https://coretus-development.s3.ap-south-1.amazonaws.com/" + ingradient_file
                    await gallery_collection.insert_one({
                        'user_id': str(users['_id']),
                        'type': 'cocktail',
                        'image': ing_image,
                        'date': datetime.today(),
                        'created_at': datetime.today(),
                        'updated_at': datetime.today()
                    })
                    cocktail_ocr_data = await self.get_cocktail({"cocktail": ing_image})
                elif image_url is not None:
                    cocktail_ocr_data = await self.get_cocktail({"cocktail": image_url})
                else:
                    cocktail_ocr_data = await self.get_cocktail({"ingradient": cocktail_req['ingradients']})
                if 'cocktail_id' in cocktail_ocr_data and cocktail_ocr_data is not None:
                    fav_data = await favourite_collection.find_one({'user_id': str(users['_id'])})
                    if fav_data:
                        fav_cocktail = fav_data['suggest_cocktail_search'] if 'suggest_cocktail_search' in fav_data and \
                                                                              fav_data[
                                                                                  'suggest_cocktail_search'] != [] else []
                    cocktail_detail = {}
                    cocktail_detail_data = []
                    query = cocktail_ocr_data['cocktail_id']
                    # query['new_time'] = query['nutrition_facts'].apply(
                    #     lambda ing: " ".join([lst['amount']+lst['unit'] if lst['name'] == "Calories" else "0 Cals" for lst in ing]))
                    if 'search' in cocktail_req and cocktail_req['search'] is not None:
                        query = query[(query['cocktail_name'].str.contains(cocktail_req['search'].title())) | (
                            query['cocktail_intro'].str.contains(cocktail_req['search'].title()))]
                        if 'cocktail_name' in query and query['cocktail_name'].count() > 0:
                            if fav_data:
                                if 'suggest_cocktail_search' in fav_data:
                                    search_cocktail = fav_data['suggest_cocktail_search']
                                    if search_cocktail.count(cocktail_req['search']) <= 0:
                                        if len(search_cocktail) >= 10:
                                            archived_search = await archived_collection.find_one(
                                                {'user_id': str(users['_id'])})
                                            if archived_search:
                                                if 'suggest_cocktail_search' in archived_search:
                                                    archive_cocktail_recipe = archived_search['suggest_cocktail_search']
                                                    archive_cocktail_recipe.append(cocktail_req['search'])
                                                    archived_collection.update_one({'user_id': str(users['_id'])}, {
                                                        "$set": {"suggest_cocktail_search": archive_cocktail_recipe,
                                                                 'updated_at': datetime.today()}})
                                                else:
                                                    fav_search = fav_data['suggest_cocktail_search']
                                                    archive_cocktail_recipe = fav_search
                                                    archive_cocktail_recipe.append(cocktail_req['search'])
                                                    archived_collection.update_one({'user_id': str(users['_id'])}, {
                                                        "$set": {"suggest_cocktail_search": archive_cocktail_recipe,
                                                                 'updated_at': datetime.today()}})
                                            else:
                                                archive_cocktail_recipe = fav_data['suggest_cocktail_search']
                                                archive_cocktail_recipe.append(cocktail_req['search'])
                                                archived_collection.insert_one(
                                                    {'user_id': str(users['_id']),
                                                     'suggest_cocktail_search': archive_cocktail_recipe,
                                                     'created_at': datetime.today(), 'updated_at': datetime.today()})
                                            del search_cocktail[0]
                                        search_cocktail.append(cocktail_req['search'])
                                        favourite_collection.update_one({'user_id': str(users['_id'])},
                                                                        {"$set": {
                                                                            'suggest_cocktail_search': search_cocktail,
                                                                            'updated_at': datetime.today()}})
                                else:
                                    search = (f"{cocktail_req['search']}")
                                    cocktail_search = search.split(" ")
                                    favourite_collection.update_one({'user_id': str(users['_id'])},
                                                                    {"$set": {
                                                                        'suggest_cocktail_search': cocktail_search,
                                                                        'updated_at': datetime.today()}})
                            else:
                                search = (f"{cocktail_req['search']}")
                                cocktail_search = search.split(" ")
                                favourite_collection.insert_one(
                                    {'user_id': str(users['_id']), 'suggest_cocktail_search': cocktail_search,
                                     'created_at': datetime.today(),
                                     'updated_at': datetime.today()})
                    query = query[['_id', 'cocktail_name', 'cocktail_type', 'image_url', 'prep_time', 'servings']]
                    item_per_page = int(cocktail_req['item_per_page'])
                    current_page = int(cocktail_req['current_page'])
                    start_idx = (current_page - 1) * item_per_page
                    end_idx = current_page * item_per_page
                    paginated_df = query.iloc[start_idx:end_idx]
                    page_list = paginated_df.values.tolist()
                    ck_length = len(page_list)
                    cocktail_detail_data.append(page_list)
                    for values in cocktail_detail_data:
                        for cocktail_length in range(ck_length):
                            fav = fav_data['favourite_cocktail'] if 'favourite_cocktail' in fav_data else []
                            if fav != []:
                                already_fav = [ele for ele in fav if (ele == str(values[cocktail_length][0]))]
                                fav_cocktail_recipe = True if already_fav != [] else False
                            else:
                                fav_cocktail_recipe = False
                            cocktail_detail[cocktail_length] = {
                                'cocktail_id': str(values[cocktail_length][0]),
                                'cocktail_name': values[cocktail_length][1],
                                'cocktail_type': values[cocktail_length][2],
                                'cocktail_servings': str(values[cocktail_length][5]),
                                'cocktail_time': values[cocktail_length][4]['time'] + " mins",
                                # 'image':"https://coretus-development.s3.ap-south-1.amazonaws.com/cocktail_thumbnail_images/"+str(values[cocktail_length][0])+".jpg",
                                'cocktail_image': values[cocktail_length][3][0],
                                'favourite': fav_cocktail_recipe,
                            }
                    pagination = {}
                    total_records = query.shape[0]
                    total_pages = round(query.shape[0] / item_per_page)
                    pagination = {
                        "total_pages": total_pages,
                        "current_page": current_page,
                        "total_items": total_records
                    }
                    if len(cocktail_detail) >= 1:
                        data = {
                            'data': list(cocktail_detail.values()),
                            'pagination': pagination,
                            'ingradients_data': cocktail_ocr_data['ingredients'],
                            'status': True,
                            'message': "Cocktail List Gets Successfully"
                        }
                    else:
                        pagination = {
                            "total_pages": 0,
                            "current_page": 0,
                            "total_items": 0
                        }
                        data = {
                            'data': [],
                            'pagination': pagination,
                            'ingradients_data': [],
                            'status': True,
                            'message': "Cocktail List Not Found"
                        }
                else:
                    pagination = {
                        "total_pages": 0,
                        "current_page": 0,
                        "total_items": 0
                    }
                    data = {
                        'data': [],
                        'pagination': pagination,
                        'ingradients_data': [],
                        'status': True,
                        'message': "Cocktail List Not Found"
                    }
            else:
                pagination = {
                    "total_pages": 0,
                    "current_page": 0,
                    "total_items": 0
                }
                data = {
                    'data': [],
                    'pagination': pagination,
                    'ingradients_data': [],
                    'status': True,
                    'message': "You are not authorized to make the request. The authorization credentials provided for the request are invalid."
                }
            return data
        except Exception as e:
            self.logger.error(
                f"An error occurred while getting cocktail ocr data: {e} | Line: {e.__traceback__.tb_lineno}")
            return {}
        # print(cocktail_ocr_data)


# In[10]:


if __name__ == "__main__":
    async def fetch_data(collection):
        from motor.motor_asyncio import AsyncIOMotorClient

        mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                       "/?authSource=admin"
        mongo_client = AsyncIOMotorClient(mongo_db_uri)
        mongo_db = mongo_client['Eat']
        collection = mongo_db[collection]
        return collection


    async def main():
        cocktail_collection = await fetch_data('cocktail_data')
        ocr_model = CocktailOcrResult()
        await ocr_model.load_and_preprocess_data(cocktail_collection)
        return await ocr_model.get_cocktail({
            'ingradient': "rum,pinapple"})


    print(asyncio.run(main()))

# In[ ]:


# In[ ]:


# In[ ]:
