#!/usr/bin/env python
# coding: utf-8
import numpy
# In[9]:
import pandas as pd
import asyncio
import re
import motor.motor_asyncio
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import logging
from app.src.ocr_model import OCRModel
import multiprocessing
import requests
from unidecode import unidecode


class WineListOcrResult:
    def __init__(self):
        self.wine_df = None
        self.model = None
        self.combine_vector = None
        self.logger = logging.getLogger(__name__)

    async def load_and_preprocess_data(self, wine_collection: motor.motor_asyncio.AsyncIOMotorCollection) -> None:
        try:
            data = await wine_collection.find({'status': True}).to_list(length=None)
            df = pd.DataFrame(data)
            wine_df = df.copy()

            wine_df['grapes'] = wine_df['grapes'].apply(
                lambda grape_list: " ".join([unidecode(name.lower()) for name in grape_list]))

            wine_df['name'] = wine_df['name'].apply(lambda x: unidecode(x.lower()))
            wine_df['winery'] = wine_df['winery'].apply(lambda winery: unidecode(winery.lower()))

            wine_df['combine'] = wine_df['name'] + " " + wine_df['grapes'] + " " + wine_df['winery']

            self.model = TfidfVectorizer()
            self.combine_vector = self.model.fit_transform(wine_df['combine'])
            self.wine_df = wine_df
            self.logger.info("Data loaded and preprocessed successfully")
        except Exception as e:
            self.logger.error(
                f"An error occurred while loading and preprocessing the data: {e} | Line: {e.__traceback__.tb_lineno}")

    async def word_to_vector(self, query: list) -> numpy.ndarray:
        try:
            query_vector = self.model.transform(query)
            similarity = cosine_similarity(query_vector, self.combine_vector)
            return np.amax(similarity, axis=0)
        except Exception as e:
            self.logger.error(
                f"An error occurred while converting word to vector: {e} | Line: {e.__traceback__.tb_lineno}")
            return np.array([])

    # async def get_ocr_text(self, img_url: str):
    #     try:
    #         if requests.get(img_url).status_code == 200:
    #             result = ocr.ocr(img_url, cls=True)
    #             ocr_text = []
    #             for idx in range(len(result)):
    #                 res = result[idx]
    #                 for line in res:
    #                     ocr_text.append(re.sub(r'[^a-zA-Z0-9\s]', '', line[-1][0].lower()).strip())
    #             return ocr_text
    #         else:
    #             return []
    #
    #     except Exception as e:
    #         self.logger.error(f"AN error occured while getting ocr result:{e}")
    def perform_ocr(self, image: str) -> list:
        try:
            ocr = OCRModel.get_instance()
            result = ocr.ocr(image, cls=True)
            return result
        except Exception as e:
            self.logger.error(f"An error occurred while perform ocr: {e} | Line: {e.__traceback__.tb_lineno}")
            return []

    async def get_ocrtext(self, image: str, timeout: int = 60) -> list:
        try:
            if requests.get(image).status_code == 200:
                with multiprocessing.Pool(processes=8) as pool:  # Adjust the number of processes as needed
                    result = pool.apply_async(self.perform_ocr, (image,))
                    try:
                        ocr_result = result.get(timeout=timeout)
                        ocr_text = [re.sub(r'[^a-zA-Z0-9\s]', '', line[-1][0].lower()).strip() for res in ocr_result for
                                    line in res]
                        return ocr_text
                    except multiprocessing.TimeoutError:
                        self.logger.error("OCR operation timed out.")
                        return []
            else:
                return []
        except Exception as e:
            self.logger.error(f"An error occurred while getting ocr text: {e} | List: {e.__traceback__.tb_lineno}")
            return []

    async def get_winelist(self, wine_ocr: dict) -> list:
        try:
            if 'wine' in wine_ocr.keys():
                ocr_list = await self.get_ocrtext(wine_ocr['wine'])
                self.wine_df['score'] = await self.word_to_vector(ocr_list)
                suggested_wine = self.wine_df[self.wine_df['score'] > 0.6].sort_values('score', ascending=False)[
                    '_id'].values
                return [str(idx) for idx in suggested_wine]
            else:
                return []
        except Exception as e:
            self.logger.error(f"An error occurred while getting wine: {e} | Line: {e.__traceback__.tb_lineno}")
            return []


# In[10]:


if __name__ == "__main__":
    import cProfile
    import pstats

    profiler = cProfile.Profile()

    profiler.enable()


    async def fetch_data():
        mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                       "/?authSource=admin"
        from motor.motor_asyncio import AsyncIOMotorClient
        mongo_client = AsyncIOMotorClient(mongo_db_uri)
        mongo_db = mongo_client['Eat']
        wine_collection = mongo_db['wine_vivino_data']
        return wine_collection


    async def main():
        data = await fetch_data()
        winelist_model = WineListOcrResult()
        await winelist_model.load_and_preprocess_data(data)
        return await winelist_model.get_winelist(
            {
                'wine': 'https://tellerschophouse.com/wp-content/uploads/2021/07/tellers_menu_wineList_07.02.21-1.jpg'})


    print(asyncio.run(main()))
    # In[ ]:
    profiler.disable()

    p = pstats.Stats(profiler)
    p.strip_dirs().sort_stats('cumulative').print_stats()
# In[ ]:


# In[ ]:


# In[ ]:
