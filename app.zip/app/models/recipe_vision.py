# !/usr/bin/env python
# coding: utf-8
import os
import time
from datetime import datetime
import motor.motor_asyncio
import numpy
import requests
from transformers import CLIPProcessor, CLIPModel
import boto3
# In[9]:
import pandas as pd
import asyncio
from nltk.stem import WordNetLemmatizer
import string
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
from nltk.corpus import stopwords
import numpy as np
import logging
from PIL import Image
from thefuzz import process, fuzz


class RecipeVision:
    def __init__(self):
        self.recipe_df = None
        self.emb_model = None
        self.vision_model = None
        self.vision_processor = None
        self.ing_embeddings = None
        self.combine_embeddings = None
        self.ingredients = None
        self.stopset = stopwords.words('english') + list(string.punctuation)
        self.wl = WordNetLemmatizer()
        self.logger = logging.getLogger(__name__)

    async def preprocess_ingredients(self, ingredients: list) -> list:
        try:
            ingredient_list = []
            for ing in ingredients:
                ingredient_list.append(ing['ingredient'])

            return ingredient_list
        except Exception as e:
            self.logger.error(
                f"An error occurred while preprocess ingredients: {e} | Line: {e.__traceback__.tb_lineno}")
            return []

    async def load_and_preprocess_data(self, recipe_collection: motor.motor_asyncio.AsyncIOMotorCollection) -> None:
        try:
            recipe_data = await recipe_collection.find().to_list(length=None)
            df = pd.DataFrame(recipe_data)
            recipe_df = df.copy()

            recipe_df['ingredients'] = await asyncio.gather(
                *(self.preprocess_ingredients(ing) for ing in recipe_df['ingredients']))

            recipe_df['new_ingredients'] = recipe_df['ingredients'].apply(lambda ingredients: " ".join(ingredients))

            self.emb_model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
            # self.vision_model = YOLO("app/models/tornado.pt")
            self.vision_model = CLIPModel.from_pretrained("laion/CLIP-ViT-L-14-DataComp.XL-s13B-b90K")
            self.vision_processor = CLIPProcessor.from_pretrained("laion/CLIP-ViT-L-14-DataComp.XL-s13B-b90K")
            self.ingredients = list(set([ing for ing_list in recipe_df['ingredients'] for ing in ing_list]))
            # self.ing_embeddings = self.emb_model.encode(self.ingredients, show_progress_bar=True)
            self.combine_embeddings = self.emb_model.encode(recipe_df['new_ingredients'], show_progress_bar=True)
            self.recipe_df = recipe_df
            self.logger.info("Data loaded and preprocessed successfully")
        except Exception as e:
            self.logger.error(
                f"An error occurred while loading and preprocessing the data: {e} | Line: {e.__traceback__.tb_lineno}")

    async def word_to_emb(self, q_list: list, corpus: numpy.ndarray) -> numpy.ndarray:
        try:
            q_embeddings = self.emb_model.encode(q_list)
            similarity = cosine_similarity(q_embeddings, corpus)
            return np.amax(similarity, axis=0)
        except Exception as e:
            self.logger.error(
                f"An error occurred while converting word to embeddings: {e} | Line: {e.__traceback__.tb_lineno}")
            return np.array([])

    async def get_detected_ing(self, img_url: str) -> list:
        try:
            # results = self.vision_model(img_url)
            # det_list = []
            # if results:
            #     for r in results:
            #         names = r.names
            #         cls = [names[key] for key in r.boxes.cls.tolist()]
            #         conf = r.boxes.conf.tolist()
            #         for idx in range(len(cls)):
            #             if conf[idx] > 0.30:
            #                 det_list.append(cls[idx])
            #     return list(set(det_list))
            # else:
            #     return []
            if requests.get(img_url).status_code == 200:
                path = os.path.join(os.getcwd(), "", "classes.xlsx")
                df = pd.read_excel(path)
                classes = df['classes'].to_list()
                new_classes = [f"This is the photo of {name}" for name in classes]
                image = Image.open(requests.get(img_url, stream=True).raw)
                inputs = self.vision_processor(text=new_classes, images=image, return_tensors="pt", padding=True)
                outputs = self.vision_model(**inputs)
                logits_per_image = outputs.logits_per_image  # This is the image-text similarity score
                probs = logits_per_image.sigmoid()
                prob_list = probs.tolist()[0]
                print(prob_list)
                top_indices = [classes[i] for i in range(len(classes)) if prob_list[i] == 1]
                print(top_indices)
                return top_indices
            else:
                return []
        except Exception as e:
            self.logger.error(f"An error occurred while detecting object: {e} | Line: {e.__traceback__.tb_lineno}")
            return []

    async def get_ocr_recipe(self, recipe_det: dict) -> dict:
        try:
            if 'recipe' in recipe_det.keys() and recipe_det['recipe'] is not None:
                det_list = await self.get_detected_ing(recipe_det['recipe'])
                if det_list:
                    # det_similarity = await self.word_to_emb(det_list, self.ing_embeddings)
                    # similar_ingredients = list(
                    #     set([self.ingredients[np.argmax(arr)] for arr in det_similarity if max(arr) > 0.7]))
                    similar_ingredients = []
                    for name in det_list:
                        matched_list = process.extractBests(name, self.ingredients, scorer=fuzz.token_set_ratio,
                                                            score_cutoff=100)
                        for ing in matched_list:
                            similar_ingredients.append(ing[0])
                    if similar_ingredients:
                        ingredients_similarity = await self.word_to_emb(similar_ingredients,
                                                                        self.combine_embeddings)
                        print(ingredients_similarity)
                        self.recipe_df['score'] = ingredients_similarity

                        path = os.path.join(os.getcwd(), "app/models/", recipe_det['recipe'].split("/")[-1])
                        if os.path.exists(path):
                            os.remove(path)
                        return {"recipe_id":
                                    self.recipe_df.sort_values('score', ascending=False),
                                "ingredients": det_list}
                    else:
                        path = os.path.join(os.getcwd(), "app/models/", recipe_det['recipe'].split("/")[-1])
                        if os.path.exists(path):
                            os.remove(path)

                        return {}
                else:

                    # path = os.path.join(os.getcwd(), recipe_det['recipe'].split("/")[-1])
                    # os.remove(path)

                    return {}
            elif 'ingradient' in recipe_det.keys() and recipe_det['ingradient'] is not None:
                add_list = recipe_det['ingradient'].split(",")
                if add_list:
                    # add_similarity = await self.word_to_emb(add_list, self.ing_embeddings)
                    # similar_ingredients = list(set([self.ingredients[np.argmax(arr)] for arr in add_similarity if
                    #                                 max(arr) > 0.70]))
                    similar_ingredients = []
                    for name in add_list:
                        matched_list = process.extractBests(name, self.ingredients, scorer=fuzz.token_set_ratio,
                                                            score_cutoff=100)
                        for ing in matched_list:
                            similar_ingredients.append(ing[0])
                    if similar_ingredients:
                        ingredients_similarity = await self.word_to_emb(similar_ingredients,
                                                                        self.combine_embeddings)
                        self.recipe_df['score'] = ingredients_similarity
                        return {"recipe_id":
                                    self.recipe_df.sort_values('score', ascending=False),
                                "ingredients": add_list}
                    else:
                        return {}
                else:
                    return {}
            else:
                return {}
        except Exception as e:
            self.logger.error(f"An error occurred while getting recipes: {e} | Line: {e.__traceback__.tb_lineno}")
            return {}

    async def get_recipe_ocr_data(self, recipe_data: dict, customers_collection, archived_collection, fav_collection,
                                  allergies_collection, recipes_collection, gallery_collection):

        global data, calorie_from, calorie_to, fav_liked_recipe, fav_disliked_recipe
        image = recipe_data['image']
        image_url = recipe_data['image_url']
        users = await customers_collection.find_one({"verify_token": recipe_data['token']})
        if users:
            if recipe_data['type'] == "recipe":
                if image is not None:
                    s3 = boto3.client(
                        "s3",
                        aws_access_key_id="AKIAYLJH7CDVSNC6YWV7",
                        aws_secret_access_key="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",
                        region_name="ap-south-1"
                    )
                    # ingrediant_file = f"wine/{user_id}/{str(int(time.time()))}.{image.filename.split('.')[-1]}"
                    ingradient_file = "recipe/" + str(users['_id']) + "/" + str(int(time.time())) + "." + \
                                      image.filename.split('.')[-1]

                    s3.upload_fileobj(image.file, "coretus-development", ingradient_file,
                                      ExtraArgs={'ACL': 'public-read'})
                    ing_image = "https://coretus-development.s3.ap-south-1.amazonaws.com/" + ingradient_file
                    await gallery_collection.insert_one({
                        'user_id': str(users['_id']),
                        'type': 'recipe',
                        'image': ing_image,
                        'date': datetime.today(),
                        'created_at': datetime.today(),
                        'updated_at': datetime.today()
                    })
                    recipe_ocr_data = await self.get_ocr_recipe({"recipe": ing_image})

                elif image_url is not None:
                    recipe_ocr_data = await self.get_ocr_recipe({"recipe": image_url})
                else:

                    recipe_ocr_data = await self.get_ocr_recipe({"ingradient": recipe_data['ingradients']})

                # print(recipe_ocr_data)
                # data = await recipes_collection.find({}).to_list(length=None)
                # df = pd.DataFrame(data)
                if 'recipe_id' in recipe_ocr_data and recipe_ocr_data is not None:
                    fav_data = await fav_collection.find_one({'user_id': str(users['_id'])})
                    if fav_data:
                        fav_liked_recipe = fav_data['liked_recipe'] if 'liked_recipe' in fav_data and fav_data[
                            'liked_recipe'] != [] else []
                        fav_disliked_recipe = fav_data['disliked_recipe'] if 'disliked_recipe' in fav_data and fav_data[
                            'disliked_recipe'] != [] else []
                    else:
                        fav_liked_recipe = []
                        fav_disliked_recipe = []
                    fav_liked = []
                    disliked = []
                    recipe_detail = {}
                    recipe_detail_data = []
                    query = recipe_ocr_data['recipe_id']
                    # query = df
                    query['new_ingradients'] = query['ingredients'].apply(
                        lambda ing: " ".join([lst for ingr in ing for lst in ingr]))
                    # query['calorie'] = query['nutrition_facts'].apply(lambda cal: int(cal[][0]))
                    # query['categories'] = query['cuisine_type'].apply(lambda cat: cat[])
                    query['time'] = query['total_time']
                    # ingradients = "|".join(recipe_data['ingradients'].split(","))
                    # query[query['new_ingradients'].str.contains(ingradients)]
                    # query[query['status'] == True]
                    calorie_from = int(recipe_data['calorie_from']) if 'calorie_from' in recipe_data and recipe_data[
                        'calorie_from'] != "" else 0
                    calorie_to = int(recipe_data['calorie_to']) if 'calorie_to' in recipe_data and recipe_data[
                        'calorie_from'] != "" else 0

                    total_time_from = int(recipe_data['total_time_from']) if 'total_time_from' in recipe_data and \
                                                                             recipe_data['total_time_from'] != "" else 0
                    total_time_to = int(recipe_data['total_time_to']) if 'total_time_to' in recipe_data and recipe_data[
                        'total_time_to'] != "" else 0
                    # if 'calorie_from' in recipe_data and 'calorie_to' in recipe_data and calorie_from != 0 and \
                    #         calorie_to != 0:
                    #     query = query[
                    #         (query['calorie'] >= calorie_from) & (
                    #                 query['calorie'] < calorie_to)]
                    # if 'category' in recipe_data and recipe_data['category'] != None:
                    #     query = query[query['categories'].str.contains(recipe_data['category'].capitalize())]
                    # if 'total_time_from' in recipe_data and 'total_time_to' in recipe_data and total_time_to != 0 and \
                    #         total_time_from != None:
                    #     query = query[(query['time'] >= total_time_from) & (
                    #             query['time'] < total_time_to)]
                    # if 'fav' in recipe_data and recipe_data['fav'] is not None and fav_liked_recipe != [] and \
                    #         recipe_data['fav'] == 'like':
                    #     for fav_recipe in fav_liked_recipe:
                    #         fav_liked.append(ObjectId(fav_recipe))
                    #     query = query[query['_id'].isin(fav_liked)]
                    #     # query['like'] = True if query[query['_id'].isin(fav_liked)] else False
                    # if 'fav' in recipe_data and recipe_data['fav'] is not None and fav_disliked_recipe != [] and \
                    #         recipe_data['fav'] == 'dislike':
                    #     for fav_recipe in fav_disliked_recipe:
                    #         disliked.append(ObjectId(fav_recipe))
                    #     query = query[query['_id'].isin(disliked)]

                    if recipe_data['search'] and 'search' in recipe_data and recipe_data['search'] != None:
                        query = query[(query['recipe_name'].str.contains(recipe_data['search'].capitalize())
                                       | (query['new_ingradients'].str.contains(recipe_data['search'])))
                        ]
                        # print(query)
                        if 'recipe_name' in query and query['recipe_name'].count() > 0:
                            if fav_data:
                                if 'search_recipe' in fav_data:
                                    search_recipe = fav_data['search_recipe']
                                    # print(search_recipe)
                                    already_nm = recipe_data['search'] in set(search_recipe)
                                    print(already_nm)
                                    if already_nm == False:
                                        if search_recipe.count(recipe_data['search']) <= 0:
                                            if len(search_recipe) >= 10:
                                                archived_search = await archived_collection.find_one(
                                                    {'user_id': str(users['_id'])})
                                                if archived_search:

                                                    if 'search_recipe' in archived_search:
                                                        archive_search_recipe = archived_search['search_recipe']
                                                        archive_search_recipe.append(recipe_data['search'])
                                                        archived_collection.update_one({'user_id': str(users['_id'])},
                                                                                       {
                                                                                           "$set": {
                                                                                               "search_recipe": archive_search_recipe,
                                                                                               'updated_at': datetime.today()}})
                                                    else:
                                                        fav_search = fav_data['search_recipe']
                                                        archive_search_recipe = fav_search
                                                        archive_search_recipe.append(recipe_data['search'])
                                                        archived_collection.update_one({'user_id': str(users['_id'])},
                                                                                       {
                                                                                           "$set": {
                                                                                               "search_recipe": archive_search_recipe,
                                                                                               'updated_at': datetime.today()}})
                                                else:
                                                    archive_search_recipe = fav_data['search_recipe']
                                                    archive_search_recipe.append(recipe_data['search'])
                                                    archived_collection.insert_one(
                                                        {'user_id': str(users['_id']),
                                                         'search_recipe': archive_search_recipe,
                                                         'created_at': datetime.today(),
                                                         'updated_at': datetime.today()})

                                                del search_recipe[0]
                                            search_recipe.append(recipe_data['search'])
                                            fav_collection.update_one({'user_id': str(users['_id'])},
                                                                      {"$set": {'search_recipe': search_recipe,
                                                                                'updated_at': datetime.today()}})
                                        else:
                                            search_recipe.append(recipe_data['search'])
                                            fav_collection.update_one({'user_id': str(users['_id'])},
                                                                      {"$set": {'search_recipe': search_recipe,
                                                                                'updated_at': datetime.today()}})
                                else:
                                    search = (f"{recipe_data['search']}")
                                    search_recipe = search.split(" ")
                                    fav_collection.update_one({'user_id': str(users['_id'])},
                                                              {"$set": {'search_recipe': search_recipe,
                                                                        'updated_at': datetime.today()}})
                            else:
                                search = (f"{recipe_data['search']}")
                                search_recipe = search.split(" ")
                                fav_collection.insert_one(
                                    {'user_id': str(users['_id']), 'search_recipe': search_recipe,
                                     'created_at': datetime.today(),
                                     'updated_at': datetime.today()})
                    query = query[
                        ['_id', 'recipe_name', 'time', 'images', 'nutrition_facts', 'new_ingradients',
                         'difficulty_level']]
                    item_per_page = int(recipe_data['item_per_page'])
                    current_page = int(recipe_data['current_page'])
                    start_idx = (current_page - 1) * item_per_page
                    end_idx = current_page * item_per_page
                    paginated_df = query.iloc[start_idx:end_idx]
                    page_list = paginated_df.values.tolist()

                    r_length = len(page_list)
                    recipe_detail_data.append(page_list)
                    # allergie = allergies_collection.find({'user_id': str(users['_id'])})
                    # al_list = await allergie.to_list(length=100)
                    # allergies_data = []
                    # if allergie:
                    #     for aller in al_list:
                    #         allergies_data.append(aller['allergy'])
                    # else:
                    #     allergies_data = []
                    #
                    for values in recipe_detail_data:

                        for recipe_length in range(len(values)):
                            fav = fav_data[
                                'liked_recipe'] if fav_data is not None and 'liked_recipe' in fav_data else []
                            dislikedfav = fav_data[
                                'disliked_recipe'] if fav_data is not None and 'disliked_recipe' in fav_data else []
                            favourite = fav_data[
                                'favourite_recipe'] if fav_data is not None and 'favourite_recipe' in fav_data else []

                            # allergies_detail = False
                            # allerg_data = allergies_data+values[recipe_length][7]
                            # for a_d in allerg_data:
                            #     ingre = values[recipe_length][5]
                            #
                            #     allergies_detail = True if ingre.find(a_d) != -1 else False
                            liked_recipe = True if fav != [] and str(values[recipe_length][0]) in fav else False
                            disliked_recipe = True if dislikedfav != [] and str(
                                values[recipe_length][0]) in dislikedfav else False
                            fav_recipe = True if favourite != [] and str(
                                values[recipe_length][0]) in favourite else False
                            calories_data = next(
                                item for item in values[recipe_length][4] if item['name'] == 'Calories')
                            if liked_recipe == True:
                                preferences = 1
                            elif disliked_recipe == True:
                                preferences = -1
                            else:
                                preferences = 0
                            recipe_detail[recipe_length] = {
                                'recipe_id': str(values[recipe_length][0]),
                                'recipe_name': values[recipe_length][1],
                                'total_time': str(values[recipe_length][2]['time']) + " " + str(
                                    values[recipe_length][2]['unit']),
                                # 'image': "https://coretus-development.s3.ap-south-1.amazonaws.com/recipe_thumbnail_images/" + str(
                                #     values[recipe_length][0]) + ".jpg",

                                'recipe_image': values[recipe_length][3][0],
                                # 'calories': str(values[recipe_length][4]) + " Cals",
                                'calories': str(calories_data['amount']) + " " + str(calories_data['unit']),
                                'preferences': preferences,
                                'difficulty_level': values[recipe_length][6],
                                # 'like': liked_recipe,
                                # 'dislike': disliked_recipe,
                                # 'none': True if liked_recipe == False and disliked_recipe == False else False,
                                # 'allergy': allergies_detail,
                                'favorite': fav_recipe
                            }

                    pagination = {}
                    total_records = query.shape[0]
                    total_pages = round(query.shape[0] / item_per_page)
                    pagination = {
                        "total_pages": total_pages,
                        "current_page": current_page,
                        "total_items": total_records
                    }
                    data = {
                        'data': list(recipe_detail.values()),
                        # 'ingradient_data': [],
                        'ingradient_data': recipe_ocr_data['ingredients'],
                        'pagination': pagination,
                        'status': True,
                        'message': "Recipe Data Get Successfully"
                    }
                    print(data)
                else:
                    pagination = {
                        "total_pages": 0,
                        "current_page": 0,
                        "total_items": 0
                    }
                    data = {
                        'data': [],
                        'ingradient_data': [],
                        'pagination': pagination,
                        'status': True,
                        'message': "Recipe Data Get Successfully"
                    }
                    print(data)
                    # data = {}
            else:
                result = []
                random_recipe = self.recipe_df.sample(n=15)
                query = random_recipe
                query['new_ingradients'] = query['ingredients'].apply(
                    lambda ing: " ".join([lst for ingr in ing for lst in ingr]))
                query['time'] = query['total_time']

                # query['new_ingradients'] = query['ingredient'].apply(
                #     lambda ing: " ".join([lst[-1] for ingr in ing.values() for lst in ingr]))
                # query['calorie'] = query['nutritions'].apply(lambda cal: int(cal[0][0]))
                # query['categories'] = query['category'].apply(lambda cat: cat[0])
                # query['time'] = query['total_time'].apply(lambda cat: int(cat))
                # ingradients = "|".join(recipe_data['ingradients'].split(","))
                # query[query['new_ingradients'].str.contains(ingradients)]
                query = query[
                    ['_id', 'recipe_name', 'time', 'images', 'nutrition_facts', 'new_ingradients', 'difficulty_level']]
                result.append(query.values)
                recipe_data = {}
                fav_data = await fav_collection.find_one({'user_id': str(users['_id'])})
                if fav_data:
                    fav_liked_recipe = fav_data['liked_recipe'] if 'liked_recipe' in fav_data and fav_data[
                        'liked_recipe'] != [] else []
                    fav_disliked_recipe = fav_data['disliked_recipe'] if 'disliked_recipe' in fav_data and fav_data[
                        'disliked_recipe'] != [] else []
                    favorite = fav_data['favourite_recipe'] if 'favourite_recipe' in fav_data and fav_data[
                        'favourite_recipe'] != [] else []
                if result is not None:
                    # print(fav_data)
                    if fav_data is not None:

                        if 'liked_recipe' in fav_data:
                            if fav_data['liked_recipe'] is not None:
                                fav = fav_data['liked_recipe']
                            else:
                                fav = []
                        else:
                            fav = []
                        if 'favourite_recipe' in fav_data:
                            if fav_data['favourite_recipe'] is not None:
                                fav_rec = fav_data['favourite_recipe']
                            else:
                                fav_rec = []
                        else:
                            fav_rec = []
                        if 'disliked_recipe' in fav_data:
                            if fav_data['disliked_recipe'] is not None:
                                dislikedfav = fav_data['disliked_recipe']
                            else:
                                dislikedfav = []
                        else:
                            dislikedfav = []
                    else:
                        fav = []
                        dislikedfav = []
                        fav_rec = []

                    # fav = fav_data['liked_recipe'] if fav_data['liked_recipe'] is not None and 'liked_recipe' in fav_data else []
                    # dislikedfav = fav_data['disliked_recipe'] if 'disliked_recipe' in fav_data else []

                    for recipe in result:
                        for r_len in range(0, 15):
                            # fav = fav_data['liked_recipe'] if 'liked_recipe' in fav_data else []
                            fav_like_recipe = {}
                            liked_recipe = True if fav != [] and str(recipe[r_len][0]) in fav else False
                            disliked_recipe = True if dislikedfav != [] and str(
                                recipe[r_len][0]) in dislikedfav else False
                            fav_recipe = True if fav_rec != [] and str(
                                recipe[r_len][0]) in fav_rec else False

                            calories_data = next(item for item in recipe[r_len][4] if item['name'] == 'Calories')
                            # print(recipe)
                            if liked_recipe == True:
                                preferences = 1
                            elif disliked_recipe == True:
                                preferences = -1
                            else:
                                preferences = 0
                            recipe_data[r_len] = {
                                'recipe_id': str(recipe[r_len][0]),
                                'recipe_name': recipe[r_len][1],
                                'total_time': str(recipe[r_len][2]['time']) + " " + str(
                                    recipe[r_len][2]['unit']),
                                # 'image': "https://coretus-development.s3.ap-south-1.amazonaws.com/recipe_thumbnail_images/" + str(
                                #     recipe[r_len][0]) + ".jpg",

                                'recipe_image': recipe[r_len][3][0],
                                # 'calories': str(recipe[r_len][4]) + " Cals",
                                'calories': str(calories_data['amount']) + " " + str(calories_data['unit']),
                                'preferences': preferences,
                                'difficulty_level': recipe[r_len][6],
                                # 'like': liked_recipe,
                                # 'dislike': disliked_recipe,
                                # 'none': True if liked_recipe == False and disliked_recipe == False else False,
                                # 'allergy': allergies_detail,
                                'favorite': fav_recipe
                                # '_id': str(recipe[r_len][0]),
                                # 'title': recipe[r_len][1],
                                # 'image': "https://coretus-development.s3.ap-south-1.amazonaws.com/recipe_thumbnail_images/" + str(
                                #     recipe[r_len][0]) + ".jpg",
                                # # 'image': recipe[r_len][3].replace("recipes","recipe_thumbnail_images"),
                                # 'calories': str(recipe[r_len][4]) + " Cals",
                                # 'time': str(recipe[r_len][2]) + " mins",
                                # 'like': liked_recipe,
                                # 'dislike': disliked_recipe,
                                # 'none': True if liked_recipe == False and disliked_recipe == False else False,
                                # 'favorite': fav_rec
                            }
                            pagination = {
                                "total_pages": 0,
                                "current_page": 0,
                                "total_items": 0
                            }
                    data = {

                        'data': list(recipe_data.values()),
                        'ingradient_data': [],
                        'pagination': pagination,
                        'status': True,
                        'message': "Recipe List Gets Successfully"
                    }
                # data = {}
                else:
                    pagination = {
                        "total_pages": 0,
                        "current_page": 0,
                        "total_items": 0
                    }
                    data = {
                        'data': [],
                        'status': True,
                        'ingradient_data': [],
                        'pagination': pagination,
                        'message': "Recipe List Not Found"
                    }

        else:
            pagination = {
                "total_pages": 0,
                "current_page": 0,
                "total_items": 0
            }
            data = {
                'data': [],
                'pagination': pagination,
                'ingradients_data': [],
                'status': True,
                'message': "You are not authorized to make the request. The authorization credentials provided for the request are invalid."
            }
        return data


# In[10]:


if __name__ == "__main__":
    async def fetch_data(collection):
        from motor.motor_asyncio import AsyncIOMotorClient

        mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                       "/?authSource=admin"
        mongo_client = AsyncIOMotorClient(mongo_db_uri)
        mongo_db = mongo_client['Eat']
        collection = mongo_db[collection]
        return collection


    async def main():
        recipe_collection = await fetch_data('recipe_data')
        model = RecipeVision()
        await model.load_and_preprocess_data(recipe_collection)
        return await model.get_ocr_recipe(recipe_det={
            'recipe': "http://0.0.0.0:8001/images.jpeg"})


    print(asyncio.run(main()))

# In[ ]:


# In[ ]:


# In[ ]:
