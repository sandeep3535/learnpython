#!/usr/bin/env python
# coding: utf-8
import numpy
# In[9]:

import pandas as pd
import asyncio
import motor.motor_asyncio
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS
from sklearn.metrics.pairwise import cosine_similarity
from bson import ObjectId
import numpy as np
import logging
from unidecode import unidecode


class Similarwine:
    def __init__(self):
        self.wine_df = None
        self.vectorizer = None
        self.combine_vector = None
        self.logger = logging.getLogger(__name__)

    async def load_and_preprocess_data(self, wine_collection: motor.motor_asyncio.AsyncIOMotorCollection) -> None:
        try:
            data = await wine_collection.find({'status': True}).to_list(length=None)
            df = pd.DataFrame(data)
            wine_df = df.copy()

            wine_df['grapes'] = wine_df['grapes'].apply(
                lambda grape_list: " ".join([unidecode(name.lower()) for name in grape_list]))
            wine_df['region'] = wine_df['region'].apply(
                lambda region: " ".join([unidecode(name.lower()) for name in region]))
            wine_df['type'] = wine_df['type'].apply(lambda wine_type: unidecode(wine_type.lower()))
            wine_df['winery'] = wine_df['winery'].apply(lambda winery: unidecode(winery.lower()))
            wine_df['country'] = wine_df['country'].apply(lambda country: unidecode(country.lower()))

            wine_df['combine'] = wine_df['type'] + "  " + wine_df["grapes"] + " " + wine_df['winery'] + " " + \
                                 wine_df['country'] + " " + wine_df['region']

            self.vectorizer = TfidfVectorizer()
            self.combine_vector = self.vectorizer.fit_transform(wine_df['combine'])
            self.wine_df = wine_df
            self.logger.info("Data loaded and preprocessed successfully")
        except Exception as e:
            self.logger.error(
                f"An error occurred while loading and preprocessing the data: {e} | Line: {e.__traceback__.tb_lineno}")

    async def word_to_vector(self, inputs: list) -> numpy.ndarray:
        try:
            inp_vector = self.vectorizer.transform(inputs)
            similarity = np.amax(cosine_similarity(inp_vector, self.combine_vector), axis=0)
            return similarity
        except Exception as e:
            self.logger.error(
                f"An error occurred while converting word to vector: {e} | Line: {e.__traceback__.tb_lineno}")
            return np.array([])

    async def get_similar_wine(self, wine_id: str, n: int) -> list:
        try:
            similar_id = self.wine_df[self.wine_df['_id'] == ObjectId(wine_id)][
                ['type', 'grapes', 'country', 'region', 'winery']].values
            self.wine_df['score'] = await self.word_to_vector(inputs=similar_id[0])
            similar_ids = self.wine_df.sort_values('score', ascending=False)['_id'][1:n + 1]
            return [str(idx) for idx in similar_ids]
        except Exception as e:
            self.logger.error(f"An error occurred while getting similar wine: {e} | Line: {e.__traceback__.tb_lineno}")
            return []


# In[10]:


if __name__ == "__main__":
    from tqdm import tqdm


    async def fetch_data():
        mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                       "/?authSource=admin"
        from motor.motor_asyncio import AsyncIOMotorClient
        mongo_client = AsyncIOMotorClient(mongo_db_uri)
        mongo_db = mongo_client['Eat']
        wine_collection = mongo_db['wine_vivino_data']
        data = await wine_collection.find({'status': True}).to_list(length=None)
        wine_df = pd.DataFrame(data)
        ids = wine_df['_id'].astype('str').to_list()
        return ids, wine_collection


    async def main():
        data = await fetch_data()
        ids = data[0]
        recommendation_model = Similarwine()
        await recommendation_model.load_and_preprocess_data(data[1])
        with tqdm(total=len(ids)) as pbar:
            for id in ids:
                similar_wines = await recommendation_model.get_similar_wine(id, 10)
                if len(similar_wines) < 10:
                    break
                pbar.update(1)


    asyncio.run(main())

# In[ ]:


# In[ ]:


# In[ ]:
