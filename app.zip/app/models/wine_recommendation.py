#!/usr/bin/env python
# coding: utf-8
import numpy
# In[9]:

import pandas as pd
import asyncio
import re
from tqdm import tqdm
import motor.motor_asyncio
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from nltk.stem import WordNetLemmatizer
from bson import ObjectId
import numpy as np
import logging
from unidecode import unidecode
from nltk.corpus import stopwords
import string


class WineRecommendationModel:
    def __init__(self):
        self.wine_df = None
        self.vectorizer = None
        self.combine_vectors = None
        self.stopset = stopwords.words('english') + list(string.punctuation)
        self.wl = WordNetLemmatizer()
        self.logger = logging.getLogger(__name__)

    async def preprocess_text(self, text: str) -> str:
        try:

            text = unidecode(text)
            text = re.sub(r'[^\w\s]', '', text)
            text = re.sub(r'\d', '', text)
            text = re.sub(r'[^a-zA-Z0-9_ -]', '', text)

            word_lst = []
            words = text.split(" ")
            for word in words:
                word = word.lower()
                word = self.wl.lemmatize(word)
                if word not in self.stopset:
                    word_lst.append(word)
            word_str = " ".join(word_lst)
            return word_str
        except Exception as e:
            self.logger.error(f"An error occurred while preprocess text: {e} | Line: {e.__traceback__.tb_lineno}")
            return ""

    async def load_and_preprocess_data(self, wine_collection: motor.motor_asyncio.AsyncIOMotorCollection) -> None:
        try:
            data = await wine_collection.find().to_list(length=None)
            df = pd.DataFrame(data)
            wine_df = df.copy()
            wine_df['grapes'] = wine_df['grapes'].apply(
                lambda grape_list: " ".join([unidecode(name.lower()) for name in grape_list]))
            wine_df['region'] = wine_df['region'].apply(
                lambda region: " ".join([unidecode(name.lower()) for name in region]))
            wine_df['type'] = wine_df['type'].apply(lambda wine_type: unidecode(wine_type.lower()))
            wine_df['name'] = wine_df['name'].apply(lambda wine_name: unidecode(wine_name.lower()))
            wine_df['winery'] = wine_df['winery'].apply(lambda winery: unidecode(winery.lower()))
            wine_df['country'] = wine_df['country'].apply(lambda country: unidecode(country.lower()))
            wine_df['description'] = await asyncio.gather(
                *(self.preprocess_text(description) for description in wine_df['description']))

            wine_df['combine'] = wine_df['name'] + "  " + wine_df['type'] + "  " + wine_df["grapes"] + " " + \
                                 wine_df['winery'] + " " + wine_df['country'] + " " + wine_df['region'] + " " + \
                                 wine_df['description']

            self.vectorizer = TfidfVectorizer()
            self.combine_vectors = self.vectorizer.fit_transform(tqdm(wine_df['combine']))
            self.wine_df = wine_df
            self.logger.info("Data loaded and preprocessed successfully")
        except Exception as e:
            self.logger.error(
                f"An error occurred while loading and preprocessing the data: {e} | Line: {e.__traceback__.tb_lineno}")

    async def query_recommendations(self, q_list: list) -> numpy.ndarray:
        try:
            query_vectors = self.vectorizer.transform(q_list)
            similarity = cosine_similarity(query_vectors, self.combine_vectors)
            max_similarity = np.amax(similarity, axis=0)
            return max_similarity
        except Exception as e:
            self.logger.error(
                f"An error occurred while querying recommendations: {e} | Line: {e.__traceback__.tb_lineno}")
            return np.array([])

    async def get_wine_recommendations(self, fav_collection: motor.motor_asyncio.AsyncIOMotorCollection, user_id: str, n: int) -> list:
        try:
            user_data = await fav_collection.find_one({'user_id': user_id},
                                                      {'_id': 0, 'favourite_wine': 1, 'wine_search': 1,
                                                       'wine_details': 1})
            wine_search_id = []
            if user_data:
                if 'wine_search' in user_data.keys():
                    for data in user_data['wine_search']:
                        self.wine_df['score'] = await self.query_recommendations([data])
                        sorted_wine = self.wine_df.sort_values('score', ascending=False)['_id']
                        if sorted_wine.values[0] not in wine_search_id:
                            wine_search_id.append(str(sorted_wine.values[0]))
                if 'favourite_wine' not in user_data.keys():
                    user_data['favourite_wine'] = []
                if 'wine_details' not in user_data.keys():
                    user_data['wine_details'] = []
                wine_ids = wine_search_id + user_data['favourite_wine'] + user_data['wine_details']
                wine_ids = [ObjectId(id) for id in wine_ids]
                combine_list = self.wine_df[self.wine_df['_id'].isin(wine_ids)]['combine'].to_list()
                self.wine_df['new_score'] = await self.query_recommendations(combine_list)
                if user_data['wine_details']:
                    sorted_wine = self.wine_df.sort_values('new_score', ascending=False)[
                        ['_id', 'name', 'type', 'grapes']]

                    wine_details = self.wine_df[self.wine_df['_id'] == ObjectId(user_data['wine_details'][0])][
                        ['type', 'grapes']].values[0]
                    sorted_wine = sorted_wine[
                        (sorted_wine['type'] == wine_details[0]) & sorted_wine['grapes'].apply(
                            lambda grapes: any(grape in wine_details[1] for grape in grapes))]['_id'].values
                    return [str(id) for id in sorted_wine[:n]]
                else:
                    sorted_ = self.wine_df.sort_values('new_score', ascending=False)['_id'].values
                    return [str(id) for id in sorted_[:n]]
            else:
                random_wine = self.wine_df['_id'].sample(n=n)
                return list(random_wine.astype(str))

        except Exception as e:
            self.logger.error(
                f"An error occurred while getting recommendations(wine) for user {user_id}: {e} | Line: {e.__traceback__.tb_lineno}")
            return []


# In[10]:


if __name__ == "__main__":
    async def fetch_data(collection):
        from motor.motor_asyncio import AsyncIOMotorClient

        mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                       "/?authSource=admin"
        mongo_client = AsyncIOMotorClient(mongo_db_uri)
        mongo_db = mongo_client['Eat']
        collection = mongo_db[collection]
        return collection


    async def main():
        wine_collection = await fetch_data('wine_vivino_data')
        fav_collection = await fetch_data('favourite')
        recommendation_model = WineRecommendationModel()
        await recommendation_model.load_and_preprocess_data(wine_collection)
        return await recommendation_model.get_wine_recommendations(fav_collection, "651659f1d8ff3a03b70476b6", 10)


    print(asyncio.run(main()))

# In[ ]:


# In[ ]:


# In[ ]:
