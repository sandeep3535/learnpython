#!/usr/bin/env python
# coding: utf-8

# In[9]:

import pandas as pd
import asyncio
from unidecode import unidecode
from thefuzz import process, fuzz
import logging
import motor.motor_asyncio


class Foodcocktail:
    def __init__(self):
        self.spirit_types = []
        self.recipe_df = None
        self.cocktail_df = None
        self.logger = logging.getLogger(__name__)

    async def load_and_preprocess_data(self, recipe_collection: motor.motor_asyncio.AsyncIOMotorCollection, cocktail_collection: motor.motor_asyncio.AsyncIOMotorCollection) -> None:
        try:
            recipe_data = await recipe_collection.find().to_list(length=None)
            cocktail_data = await cocktail_collection.find().to_list(length=None)

            self.recipe_df = pd.DataFrame(recipe_data)
            self.cocktail_df = pd.DataFrame(cocktail_data)

            self.cocktail_df['_id'] = self.cocktail_df['_id'].apply(lambda idx: str(idx))
            self.recipe_df['_id'] = self.recipe_df['_id'].apply(lambda idx: str(idx))

            self.cocktail_df['base_spirit'] = self.cocktail_df['base_spirit'].apply(
                lambda spirit: [unidecode(name.lower()) for name in spirit])

            self.recipe_df['cocktail_spirits'] = self.recipe_df['cocktail_spirits'].apply(
                lambda spirit: [unidecode(name.lower()) for name in spirit])

            self.spirit_types = list(set(name for data in self.cocktail_df['base_spirit'] for name in data))

        except Exception as e:
            self.logger.error(
                f"An error occurred while loading and preprocessing the data: {e} | Line: {e.__traceback__.tb_lineno}")

    async def get_food_cocktailpair(self, recipe_id: str, n: int) -> list:
        try:
            spirit_in_food = self.recipe_df[self.recipe_df["_id"] == recipe_id]['cocktail_spirits'].to_list()
            matched_spirit = []
            if spirit_in_food:
                for name in spirit_in_food[0]:
                    matched_list = process.extractBests(name, self.spirit_types, scorer=fuzz.ratio, score_cutoff=80)
                    for grape in matched_list:
                        matched_spirit.append(grape[0])
            if matched_spirit:
                paired_cocktail_ids = \
                    self.cocktail_df[
                        self.cocktail_df['base_spirit'].apply(lambda x: any(grp in x for grp in matched_spirit))][
                        '_id'].values
                return [str(idx) for idx in paired_cocktail_ids[:n]]
            else:
                random_cocktails = self.cocktail_df["_id"].sample(n=n)
                return list(random_cocktails.astype(str))
        except Exception as e:
            self.logger.error(
                f"An error occurred while getting food_cocktailpair: {e} | Line: {e.__traceback__.tb_lineno}")
            random_cocktails = self.cocktail_df["_id"].sample(n=n)
            return list(random_cocktails.astype(str))


# In[10]:


if __name__ == "__main__":
    mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                   "/?authSource=admin"


    async def main():
        model = Foodcocktail(mongo_db_uri)
        await model.load_and_preprocess_data()

        return await model.get_food_cocktailpair("6463291f5d83a5b35058d89e", 10)


    print(asyncio.run(main()))

# In[ ]:


# In[ ]:


# In[ ]:
