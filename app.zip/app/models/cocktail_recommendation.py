#!/usr/bin/env python
# coding: utf-8
import numpy
# In[9]:

import pandas as pd
import asyncio
from nltk.stem import WordNetLemmatizer
import string
import re
from unidecode import unidecode
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from bson import ObjectId
from nltk.corpus import stopwords
import numpy as np
import logging
import motor.motor_asyncio


class CocktailRecommendationModel:
    def __init__(self):
        self.cocktail_df = None
        self.vectorizer = None
        self.combine_vectors = None
        self.stopset = stopwords.words('english') + list(string.punctuation)
        self.wl = WordNetLemmatizer()
        self.logger = logging.getLogger(__name__)

    async def preprocess_text(self, text: str) -> str:
        try:

            text = unidecode(text)
            text = re.sub(r'[^\w\s]', '', text)
            text = re.sub(r'\d', '', text)
            text = re.sub(r'[^a-zA-Z0-9_ -]', '', text)

            word_lst = []
            words = text.split(" ")
            for word in words:
                word = word.lower()
                word = self.wl.lemmatize(word)
                if word not in self.stopset:
                    word_lst.append(word)
            word_str = " ".join(word_lst)
            return word_str
        except Exception as e:
            self.logger.error(f"An error occurred while preprocess text: {e} | Line: {e.__traceback__.tb_lineno}")
            return ""

    async def preprocess_ingredients(self, ingredients: list) -> str:
        try:
            ingredient_list = []
            for ing in ingredients:
                ingredient_list.append(ing['ingredient'])

            return " ".join(ingredient_list)
        except Exception as e:
            self.logger.error(
                f"An error occurred while preprocess ingredients: {e} | Line: {e.__traceback__.tb_lineno}")
            return ""

    async def load_and_preprocess_data(self, cocktail_collection: motor.motor_asyncio.AsyncIOMotorCollection):
        try:
            data = await cocktail_collection.find().to_list(length=None)
            df = pd.DataFrame(data)
            cocktail_df = df.copy()

            cocktail_df['ingredients'] = await asyncio.gather(
                *(self.preprocess_ingredients(ing) for ing in cocktail_df['ingredients']))
            cocktail_df['cocktail_name'] = cocktail_df['cocktail_name'].apply(lambda x: unidecode(x.lower()))
            cocktail_df['cocktail_type'] = cocktail_df['cocktail_type'].apply(
                lambda cocktail_type: " ".join([unidecode(x.lower()) for x in cocktail_type]))
            cocktail_df['base_spirit'] = cocktail_df['base_spirit'].apply(
                lambda base_spirit: " ".join([unidecode(x.lower()) for x in base_spirit]))
            cocktail_df['glassware'] = cocktail_df['glassware'].apply(
                lambda glassware: " ".join([unidecode(x.lower()) for x in glassware]))
            cocktail_df['variants'] = cocktail_df['variants'].apply(
                lambda variants: " ".join([unidecode(x.lower()) for x in variants]))
            cocktail_df['flavor_profile'] = cocktail_df['flavor_profile'].apply(
                lambda flavor_profile: " ".join([unidecode(x.lower()) for x in flavor_profile]))
            cocktail_df['cocktail_intro'] = await asyncio.gather(
                *(self.preprocess_text(description) for description in cocktail_df['cocktail_intro']))
            cocktail_df['combine'] = cocktail_df['cocktail_name'] + " " + cocktail_df['ingredients'] \
                                     + " " + cocktail_df['cocktail_type'] + " " + cocktail_df['base_spirit'] \
                                     + " " + cocktail_df['glassware'] + " " + cocktail_df['variants'] \
                                     + " " + cocktail_df['flavor_profile'] + " " + cocktail_df['cocktail_intro']

            self.vectorizer = TfidfVectorizer()
            self.combine_vectors = self.vectorizer.fit_transform(cocktail_df['combine'])
            self.cocktail_df = cocktail_df
            self.logger.info("Data loaded and preprocessed successfully")
        except Exception as e:
            self.logger.error(
                f"An error occurred while loading and preprocessing the data: {e} | Line: {e.__traceback__.tb_lineno}")

    async def word_to_vector(self, inputs: list) -> numpy.ndarray:
        try:
            inp_vector = self.vectorizer.transform(inputs)
            similarity = np.amax(cosine_similarity(inp_vector, self.combine_vectors), axis=0)
            return similarity
        except Exception as e:
            self.logger.error(
                f"An error occurred while converting word to vector: {e} | Line: {e.__traceback__.tb_lineno}")
            return np.array([])

    async def get_recommend_cocktails(self, fav_collection: motor.motor_asyncio.AsyncIOMotorCollection, user_id: str,
                                      n: int) -> list:
        try:
            fav_data = await fav_collection.find_one({'user_id': user_id},
                                                     {'favourite_cocktail': 1, 'cocktail_search': 1,
                                                      'suggest_cocktail_search': 1,
                                                      'cocktail_details': 1,
                                                      'ingradients_cocktail_search': 1})
            if fav_data:
                cocktail_search_list = []

                suggest_cocktail_search = fav_data.get('suggest_cocktail_search', [])
                ingradients_cocktail_search = fav_data.get('ingradients_cocktail_search', [])
                cocktail_search = fav_data.get('cocktail_search', [])
                favourite_cocktail = fav_data.get('favourite_cocktail', [])
                cocktail_details = fav_data.get('cocktail_details', [])
                cocktail_search_list.extend(suggest_cocktail_search)
                cocktail_search_list.extend(ingradients_cocktail_search)
                cocktail_search_list.extend(cocktail_search)

                fav_list = favourite_cocktail + cocktail_details
                fav_list = [
                    combine
                    for combine in
                    self.cocktail_df[self.cocktail_df['_id'].isin([ObjectId(id) for id in fav_list])]['combine']
                ]
                combine_list = fav_list + cocktail_search_list
                if combine_list:
                    inp_list = [
                        self.cocktail_df.assign(score=await self.word_to_vector(inputs=[data]))
                        .sort_values('score', ascending=False)
                        ['combine']
                        .values[0]
                        for data in combine_list
                    ]
                    self.cocktail_df['new_score'] = await self.word_to_vector(inputs=inp_list)
                    recommendation = self.cocktail_df.nlargest(n, 'new_score')['_id']
                    return [str(idx) for idx in recommendation]
                else:
                    random_cocktails = self.cocktail_df['_id'].sample(n=n)
                    return list(random_cocktails.astype(str))
            else:
                random_cocktails = self.cocktail_df['_id'].sample(n=n)
                return list(random_cocktails.astype(str))
        except Exception as e:
            self.logger.error(
                f"An error occurred while getting recommend cocktails: {e} | Line: {e.__traceback__.tb_lineno}")
            return []


if __name__ == "__main__":
    async def fetch_data(collection):
        from motor.motor_asyncio import AsyncIOMotorClient

        mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                       "/?authSource=admin"
        mongo_client = AsyncIOMotorClient(mongo_db_uri)
        mongo_db = mongo_client['Eat']
        collection = mongo_db[collection]
        return collection


    async def main():
        cocktail_collection = await fetch_data('cocktail_data')
        fav_collection = await fetch_data('favourite')
        recommendation_model = CocktailRecommendationModel()
        await recommendation_model.load_and_preprocess_data(cocktail_collection)
        return await recommendation_model.get_recommend_cocktails(fav_collection, "651659f1d8ff3a03b70476b6", 10)


    print(asyncio.run(main()))

# In[10]:


# In[ ]:


# In[ ]:


# In[ ]:
