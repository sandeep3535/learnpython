# !/usr/bin/env python
# coding: utf-8
import json
import time
from io import BytesIO

import boto3
import numpy
import numpy as np
import requests
from PIL import Image
# In[9]:
from ultralytics import YOLO
import asyncio
import logging
from app.src.ocr_model import OCRModel
import os
import openai
import multiprocessing

openai.organization = "org-uC9pIWGGzTncdwE6zJpOjY5u"
openai.api_key = "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"


class NutritionOcr:
    def __init__(self):
        # self.nutrition_collection = self.db['micro_nutritions']
        # self.customers_collection = self.db['customers']
        self.model = None

        self.logger = logging.getLogger(__name__)

    async def load_model(self):
        try:
            path = os.path.join(os.getcwd(), "app/models", "table_det.pt")
            self.model = YOLO(path)
            self.logger.info("Models loaded successfully")
        except Exception as e:
            self.logger.error(f"An error occurred while loading models: {e} | Line: {e.__traceback__.tb_lineno}")

    async def crop_image(self, image_link: str) -> numpy.ndarray:
        try:
            if requests.get(image_link).status_code == 200:
                image_req = requests.get(image_link)
                _image = Image.open(BytesIO(image_req.content))
                det_result = self.model(_image)
                box = []
                orig_img = []
                for r in det_result:
                    box = r.boxes.xyxy.numpy().astype('int')
                    orig_img = r.orig_img
                if len(box) > 0:
                    img = orig_img[box[0][1]:box[0][3], box[0][0]:box[0][2]]
                    return img
                else:
                    return orig_img
        except Exception as e:
            self.logger.error(f"An error occurred while cropping image: {e} | Line: {e.__traceback__.tb_lineno}")
            return np.array([])

    async def get_centroid_y(self, b_box: list) -> tuple:
        try:
            centroid_x = sum(x for x, _ in b_box) / len(b_box)
            centroid_y = sum(y for _, y in b_box) / len(b_box)
            return centroid_x, centroid_y
        except Exception as e:
            self.logger.error(f"An error occurred while getting centroid of y: {e} | Line: {e.__traceback__.tb_lineno}")
            return tuple()

    # async def get_ocrtext(self, image, result_queue):
    #     try:
    #         cropped_image = await self.crop_image(image)
    #         ocr = OCRModel.get_instance()
    #         ocr_result = ocr.ocr(cropped_image, cls=True)
    #         ocr_text_with_bbox = []
    #         for idx in range(len(ocr_result)):
    #             res = ocr_result[idx]
    #             for line in res:
    #                 ocr_text_with_bbox.append((await self.get_centroid_y(b_box=line[0]), line[-1][0]))
    #         sorted_ocr_text_with_bbox = sorted(ocr_text_with_bbox, key=lambda x: (x[0][1]))
    #         ocr_text = [text[1].lower() for text in sorted_ocr_text_with_bbox]
    #
    #         return result_queue.put(ocr_text)
    #     except Exception as e:
    #         self.logger.error(f"An error occurred while getting ocr text: {e}")
    #         return []
    def perform_ocr(self, image: numpy.ndarray) -> list:
        try:
            ocr = OCRModel.get_instance()
            result = ocr.ocr(image, cls=True)
            return result
        except Exception as e:
            self.logger.error(f"An error occurred while perform ocr: {e} | Line: {e.__traceback__.tb_lineno}")
            return []

    async def get_ocrtext(self, image: numpy.ndarray, timeout: int = 60) -> list:
        try:
            # def ocr_with_timeout(image):
            with multiprocessing.Pool(processes=1) as pool:  # Adjust the number of processes as needed
                result = pool.apply_async(self.perform_ocr, (image,))
                try:
                    ocr_result = result.get(timeout=timeout)
                    ocr_text_with_bbox = [(await self.get_centroid_y(b_box=line[0]), line[-1][0]) for res in ocr_result
                                          for line in res]
                    sorted_ocr_text_with_bbox = sorted(ocr_text_with_bbox, key=lambda x: (x[0][1]))
                    ocr_text = [text[1].lower() for text in sorted_ocr_text_with_bbox]

                    return ocr_text
                except multiprocessing.TimeoutError:
                    self.logger.error("OCR operation timed out.")
                    return []

        except Exception as e:
            self.logger.error(f"An error occurred while getting ocr text: {e} | Line: {e.__traceback__.tb_lineno}")
            return []

    async def get_all_nutrition(self, image: str) -> dict:
        try:
            cropped_image = await self.crop_image(image)
            ocr_text = await self.get_ocrtext(cropped_image)

            openai.organization = "org-uC9pIWGGzTncdwE6zJpOjY5u"
            openai.api_key = "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"

            sample_json = {
                "nutrition": {
                    "calories": "amount of calories followed by unit e.g. 90 kcal",
                    "protein": "amount of protein followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g. 13g(10%)",
                    "carbs": "amount of carbs followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g. 2.5g(2.5%)",
                    "fat": "amount of fat followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g. 2.5g(2.5%)",
                    "saturated fat": "amount of saturated fat followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g. 1.5g(2%)",
                    "trans fat": "amount of trans fat followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g. 0g(0%)",
                    "cholesterol": "amount of cholesterol followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g. 10mg(0.1%)",
                    "sodium": "amount of sodium followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g. 350mg(1%)",
                    "fibre": "amount of fibre followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g 0g(0%)",
                    "total sugars": "amount of total sugars followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g. 4g(3%)",
                    "vitamin d": "amount of vitamin d followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g. 0mcg(0%)",
                    "calcium": "amount of calcium followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g. 0mg(0%)",
                    "iron": "amount of iron followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g. 0mg(0%)",
                    "potassium": "amount of potassium followed by unit and daily percentage Value of by considering 2000 calories per day in bracket e.g. 4mg(0.2%)",
                    "serving size": "amount of serving size followed by unit e.g. 1/2 cup"
                }
            }

            nutrition = ocr_text
            input_object = [
                {"role": "system",
                 "content": f"You will be provided with OCR-recognized nutrition label data, and your task is to properly format that nutrition data according to the given structure ({sample_json}).format. If a nutrition value is not found, place 0. Do not include any explanations, only provide a RFC8259 compliant JSON response following this format without deviation {sample_json}"},
                {"role": "user",
                 "content": '{{"prompt": "{nutrition}"}}'.format(
                     nutrition=nutrition)}
            ]

            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=input_object,
                max_tokens=400,
                temperature=0.2,
                top_p=0.8
            )
            # print(eval(response['choices'][0]['message']['content']))
            nutrition_json = json.loads(response['choices'][0]['message']['content'])

            path = os.path.join(os.getcwd(), "app/models/", image.split("/")[-1])
            if os.path.exists(path):
                os.remove(path)

            if 'nutrition' not in nutrition_json:
                edited_json = list(nutrition_json.values())[0]
                if 'nutrition' not in edited_json:
                    return {}
            else:
                return nutrition_json

        except TimeoutError:
            print("The long operation timed out, but we've handled it.")
        except Exception as e:
            self.logger.error(
                f"An error occurred while getting all nutrition details: {e} | Line: {e.__traceback__.tb_lineno}")
            return {}

    async def formate_nutrition(self, img_lnk: dict) -> dict:
        try:
            nutrition = await self.get_all_nutrition(img_lnk['nutrition'])
            if type(nutrition['nutrition']) is dict:
                all_zero = all(
                    value == '0' or value == '0g(0%)' or value == '0mg(0%)' or value == '0mcg(0%)' or value == '0 kcal' or value == '0 cups'
                    for value in
                    nutrition['nutrition'].values())
                if all_zero:
                    return {}
                else:
                    return nutrition
            else:
                return {}

        except Exception as e:
            self.logger.error(f"An error occurred while formatting nutrition: {e} | Line: {e.__traceback__.tb_lineno}")
            return {}

    async def get_nutrition_ocr_data(self, nutrition_req, customers_collection):
        global nutrition_ocr_data, data
        image = nutrition_req['image']
        users = await customers_collection.find_one({"verify_token": nutrition_req['token']})
        if users:
            if image is not None:
                s3 = boto3.client(
                    "s3",
                    aws_access_key_id="AKIAYLJH7CDVSNC6YWV7",
                    aws_secret_access_key="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",
                    region_name="ap-south-1"
                )
                # ingrediant_file = f"wine/{user_id}/{str(int(time.time()))}.{image.filename.split('.')[-1]}"
                ingradient_file = "nutritions/" + str(users['_id']) + "/" + str(int(time.time())) + "." + \
                                  image.filename.split('.')[-1]

                s3.upload_fileobj(image.file, "coretus-development", ingradient_file, ExtraArgs={'ACL': 'public-read'})
                ing_image = "https://coretus-development.s3.ap-south-1.amazonaws.com/" + ingradient_file
                nutrition_ocr_data = await self.formate_nutrition({"nutrition": ing_image})

                if 'suggested_nutritions' in nutrition_ocr_data and nutrition_ocr_data is not None:
                    suggest_nutrition = {
                        "nutritions": nutrition_ocr_data['suggested_nutritions']['nutrition'],
                        "micro_nutritions": nutrition_ocr_data['suggested_nutritions'][
                            'micro-nutrition'],
                        "serving": nutrition_ocr_data['suggested_nutritions'][
                            'serving size']
                    }

                    data = {
                        'data': suggest_nutrition,
                        'status': True,
                        'message': "Nutrition List Gets Successfully"
                    }
                    return data
                else:

                    data = {
                        'data': [],
                        'status': True,
                        'message': "Nutrition List Not Found"
                    }
                    return data
            else:

                data = {
                    'data': [],
                    'status': True,
                    'message': "Nutrition List Not Found"
                }
                return data
        else:
            data = {
                'data': [],
                'status': True,
                'message': "You are not authorized to make the request. The authorization credentials provided for the request are invalid."
            }
            return data
        # print(cocktail_ocr_data)


# In[10]:


if __name__ == "__main__":
    async def main():
        mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                       "/?authSource=admin"

        ocr_model = NutritionOcr()
        await ocr_model.load_model()
        return await ocr_model.formate_nutrition(
            {
                "nutrition": "https://coretus-development.s3.ap-south-1.amazonaws.com/nutritions/64e59566c917642532058c52/1693194163.JPG"})
        # return await ocr_model.get_ocrtext(
        #     "https://tellerschophouse.com/wp-content/uploads/2021/07/tellers_menu_wineList_07.02.21-1.jpg")


    print(asyncio.run(main()))

# In[ ]:


# In[ ]:


# In[ ]:
