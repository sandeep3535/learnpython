#!/usr/bin/env python
# coding: utf-8
import os

import numpy
import numpy as np
# In[9]:
import pandas as pd
import asyncio
import re
from sentence_transformers import SentenceTransformer
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import motor.motor_asyncio
import logging
import requests
from unidecode import unidecode
import easyocr
from nltk.tokenize import regexp_tokenize
from nltk.corpus import stopwords
import string
from thefuzz import process, fuzz
import multiprocessing


class WineOcrResult:
    def __init__(self):
        self.wine_df = None
        self.model = None
        self.combine_emb = None
        self.wine_corpus = []
        self.stopset = stopwords.words('english') + list(string.punctuation)
        self.logger = logging.getLogger(__name__)

    async def load_and_preprocess_data(self, wine_collection: motor.motor_asyncio.AsyncIOMotorCollection) -> None:
        try:
            data = await wine_collection.find({'status': True}).to_list(length=None)
            df = pd.DataFrame(data)
            wine_df = df.copy()

            wine_df['name'] = wine_df['name'].apply(lambda x: unidecode(x.lower()))
            wine_df['grapes'] = wine_df['grapes'].apply(
                lambda grape_list: " ".join([unidecode(name.lower()) for name in grape_list]))
            wine_df['region'] = wine_df['region'].apply(lambda region: " ".join(region))

            wine_df['combine'] = wine_df['name']

            name_corpus = " ".join(wine_df['name'])
            grapes_corpus = " ".join(wine_df['grapes'])
            name_words = regexp_tokenize(name_corpus, "[\w']+")
            grapes_words = regexp_tokenize(grapes_corpus, "[\w']+")
            total_words = name_words + grapes_words
            total_words = list(set(total_words))
            total_words = [unidecode(word.lower()) for word in total_words if
                           len(word) != 1 and not word.isdigit()]
            self.wine_corpus = total_words

            self.model = SentenceTransformer('sentence-transformers/multi-qa-MiniLM-L6-cos-v1')

            self.combine_emb = self.model.encode(wine_df['name'], show_progress_bar=True)
            self.wine_df = wine_df
            self.logger.info("Data loaded and preprocessed successfully")
        except Exception as e:
            self.logger.error(
                f"An error occurred while loading and preprocessing the data: {e} | Line: {e.__traceback__.tb_lineno}")

    async def word_to_vector(self, query: list) -> numpy.ndarray:
        try:
            query_emb = self.model.encode(query)
            similarity = cosine_similarity(query_emb, self.combine_emb)
            return similarity[0]

        except Exception as e:
            self.logger.error(
                f"An error occurred while converting word to vector: {e} | Line: {e.__traceback__.tb_lineno}")
            return np.array([])

    # async def get_ocr_text(self, img_url: str):
    #     try:
    #         # if requests.get(img_url).status_code == 200:
    #         # result = ocr.ocr(img_url, cls=True)
    #         # ocr_text = []
    #         # for idx in range(len(result)):
    #         #     res = result[idx]
    #         #     for line in res:
    #         #         ocr_text.append(re.sub(r'[^a-zA-Z0-9\s]', '', line[-1][0].lower()).strip())
    #         # resp = urllib.request.urlopen(img_url)
    #         # image = np.asarray(bytearray(resp.read()), dtype=np.uint8)
    #         # image = cv2.imdecode(image, cv2.IMREAD_COLOR)
    #         result = self.ocr.readtext(img_url, detail=0)
    #         ocr_text = [unidecode(re.sub(r'[^a-zA-Z0-9]', '', data.lower())) for data in result]
    #         print(ocr_text)
    #         return ocr_text
    #     # else:
    #     #     return []
    #
    #     except Exception as e:
    #         self.logger.error(f"AN error occured while getting ocr result:{e}")

    def perform_ocr(self, image: str) -> list:
        try:
            ocr = easyocr.Reader(['en'], gpu=False)
            result = ocr.readtext(image, detail=0)
            return result
        except Exception as e:
            self.logger.error(f"An error occurred while perform ocr: {e} | Line: {e.__traceback__.tb_lineno}")
            return []

    # async def get_ocrtext(self, image: str, timeout: int = 60) -> list:
    #     try:
    #         if requests.get(image).status_code == 200:
    #             with multiprocessing.Pool(processes=1) as pool:  # Adjust the number of processes as needed
    #                 result = pool.apply_async(self.perform_ocr, (image,))
    #                 try:
    #                     ocr_result = result.get(timeout=timeout)
    #                     ocr_text = [unidecode(re.sub(r'[^a-zA-Z0-9]', '', data.lower())) for data in ocr_result]
    #                     return ocr_text
    #                 except multiprocessing.TimeoutError:
    #                     self.logger.error("OCR operation timed out.")
    #                     return []
    #         else:
    #             return []
    #     except Exception as e:
    #         self.logger.error(f"An error occurred while getting ocr text: {e} Line: {e.__traceback__.tb_lineno}")
    #         return []

    async def get_ocrtext(self, image: str, timeout: int = 20) -> list:
        try:
            if requests.get(image).status_code == 200:
                # Create an asyncio event loop
                loop = asyncio.get_event_loop()

                # Wrap the OCR task in an asyncio future
                async_result = loop.run_in_executor(None, self.perform_ocr, image)

                # Wait for the result with a timeout
                ocr_result = await asyncio.wait_for(async_result, timeout=timeout)

                ocr_text = [unidecode(re.sub(r'[^a-zA-Z]', '', data.lower())) for data in ocr_result]
                return list(set(ocr_text))
            else:
                return []
        except asyncio.TimeoutError:
            self.logger.error("OCR operation timed out.")
            return []
        except Exception as e:
            self.logger.error(f"An error occurred while getting ocr text: {e} Line: {e.__traceback__.tb_lineno}")
            return []

    async def get_wine_releted_word(self, img_url: str) -> list:
        try:

            ocr_text = await self.get_ocrtext(img_url)
            print(ocr_text)
            matched_words = []
            for word in ocr_text:
                matched_list = process.extract(word, self.wine_corpus, scorer=fuzz.ratio)
                if matched_list[0][1] > 80:
                    matched_words.append(matched_list[0][0])
                else:
                    if word.isdigit() and len(word) > 3:
                        matched_words.append(word)
            return [" ".join(list(set(matched_words)))]
        except Exception as e:
            self.logger.error(
                f'AN error occured while getting wine releted words:{e} | Line: {e.__traceback__.tb_lineno}')
            return []

    async def get_wine(self, wine_ocr: dict) -> list:
        try:
            if 'wine' in wine_ocr.keys():
                ocr_text = await self.get_ocrtext(wine_ocr['wine'])
                ocr_text = list(filter(None, ocr_text))
                print(ocr_text)
                # if wine_ocr['type'].lower() == 'label':
                if ocr_text:
                    self.wine_df['score'] = await self.word_to_vector([" ".join(ocr_text)])
                    if max(self.wine_df['score']) > 0:
                        matched_df = self.wine_df[self.wine_df['score'] > 0.5]
                        best_match_grape = self.wine_df['grapes'][np.argmax(self.wine_df['score'])]
                        best_match_country = self.wine_df['country'][np.argmax(self.wine_df['score'])]
                        grape_country_df = matched_df[
                            matched_df.apply(lambda row: set(best_match_grape).issubset(row['grapes']), axis=1) &
                            (matched_df['country'] == best_match_country)
                            ][['_id', 'score']]
                        grape_df = \
                            matched_df[matched_df.apply(lambda row: set(best_match_grape).issubset(row['grapes']), axis=1)][
                                ['_id', 'score']]
                        country_df = matched_df[matched_df['country'] == best_match_country][['_id', 'score']]
                        final_df = pd.concat(
                            [grape_country_df, grape_df, country_df, matched_df[['_id', 'score']]]).drop_duplicates()
                        final_df = final_df.reset_index(drop=True)
                        # print(final_df.sort_values('score', ascending=False)[['_id', 'score']].values[0])
                        data_dicts = [{'id': str(data[0]), 'prob': data[1]} for data in final_df.values]
                        print(final_df.sort_values('score', ascending=False))
                        return data_dicts
                    else:
                        return []
                # elif wine_ocr['type'].lower() == 'suggest':
                #     self.wine_df['score'] = await self.word_to_vector(ocr_text)
                #     if max(self.wine_df['score']) > 0.4:
                #         matched_list = self.wine_df.sort_values('score', ascending=False)['_id'].values[:32]
                #         return [str(id) for id in matched_list]
                #     else:
                #         return []
                else:
                    return []
            else:
                return []
        except Exception as e:
            self.logger.error(f"An error occurred while getting wine: {e} | Line: {e.__traceback__.tb_lineno}")
            return []


# In[10]:


if __name__ == "__main__":
    async def fetch_data():
        mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                       "/?authSource=admin"
        from motor.motor_asyncio import AsyncIOMotorClient
        mongo_client = AsyncIOMotorClient(mongo_db_uri)
        mongo_db = mongo_client['Eat']
        wine_collection = mongo_db['wine_vivino_data']
        return wine_collection


    async def main():
        data = await fetch_data()
        recommendation_model = WineOcrResult()
        await recommendation_model.load_and_preprocess_data(data)
        # for data in os.listdir('/home/coretus-21/Downloads/Wine/'):

        print(data, " :", await recommendation_model.get_wine(
            {
                'wine': 'http://0.0.0.0:8001/IMG_1203.jpg'}))

    asyncio.run(main())


