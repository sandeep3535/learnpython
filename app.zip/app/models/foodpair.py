#!/usr/bin/env python
# coding: utf-8

# In[9]:

import pandas as pd
import asyncio
from unidecode import unidecode
from thefuzz import process, fuzz
import logging
import motor.motor_asyncio


class Winefoodsuggetion:
    def __init__(self):
        self.grapes_varieties = []
        self.recipe_df = None
        self.wine_df = None
        self.logger = logging.getLogger(__name__)

    async def split_wine_grapes(self, grapes_list: list) -> list:
        try:
            split_list = []
            for name in grapes_list:
                name = unidecode(name.lower())
                split_list.extend(name.split("/"))
            return split_list
        except Exception as e:
            self.logger.error(f"An error occurred while split_wine_grapes:{e} | Line: {e.__traceback__.tb_lineno}")
            return []

    async def load_and_preprocess_data(self, recipe_collection: motor.motor_asyncio.AsyncIOMotorCollection,
                                       wine_collection: motor.motor_asyncio.AsyncIOMotorCollection) -> None:
        try:
            recipe_data = await recipe_collection.find().to_list(length=None)
            wine_data = await wine_collection.find().to_list(length=None)

            self.recipe_df = pd.DataFrame(recipe_data)
            self.wine_df = pd.DataFrame(wine_data)

            self.wine_df['_id'] = self.wine_df['_id'].apply(lambda idx: str(idx))
            self.recipe_df['_id'] = self.wine_df['_id'].apply(lambda idx: str(idx))

            self.wine_df['grapes'] = await asyncio.gather(
                *(self.split_wine_grapes(grape_list) for grape_list in self.wine_df['grapes']))

            self.recipe_df['wine_grapes'] = self.recipe_df['wine_grapes'].apply(
                lambda grapes_list: [unidecode(grape.lower()) for grape in grapes_list])

            self.grapes_varieties = list(
                set(unidecode(grape.lower()) for grape_list in self.recipe_df['wine_grapes'] for grape in grape_list))
        except Exception as e:
            self.logger.error(
                f"An error occurred while loading and preprocessing the data: {e} | Line: {e.__traceback__.tb_lineno}")

    async def get_foodpair(self, wine_id: str, n: int) -> list:
        try:
            grapes_in_wine = self.wine_df[self.wine_df['_id'] == wine_id]['grapes'].to_list()
            matched_grapes = []
            if grapes_in_wine:
                for name in grapes_in_wine[0]:
                    matched_list = process.extractBests(name, self.grapes_varieties, scorer=fuzz.ratio, score_cutoff=80)
                    for grape in matched_list:
                        matched_grapes.append(grape[0])
            if matched_grapes:
                paired_food_ids = \
                    self.recipe_df[
                        self.recipe_df['wine_grapes'].apply(lambda x: any(grp in x for grp in matched_grapes))][
                        '_id'].values
                return [str(idx) for idx in paired_food_ids[:n]]
            else:
                random_recipe = self.recipe_df["_id"].sample(n=n)
                return list(random_recipe.astype(str))
        except Exception as e:
            self.logger.error(f"An error occurred while getting foodpair: {e} | Line: {e.__traceback__.tb_lineno}")
            random_food = self.recipe_df["_id"].sample(n=n)
            return list(random_food.astype(str))


# In[10]:


if __name__ == "__main__":
    mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                   "/?authSource=admin"


    async def main():
        model = Winefoodsuggetion(mongo_db_uri)
        await model.load_and_preprocess_data()

        return await model.get_foodpair("6463291f5d83a5b35058d89e", 10)


    print(asyncio.run(main()))

# In[ ]:


# In[ ]:


# In[ ]:
