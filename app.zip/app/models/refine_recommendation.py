#!/usr/bin/env python
# coding: utf-8
import numpy
# In[9]:

import pandas as pd
import asyncio
from nltk.stem import WordNetLemmatizer
import string
import re
from unidecode import unidecode
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
from bson import ObjectId
from nltk.corpus import stopwords
import numpy as np
import motor.motor_asyncio
import logging


class RecipeRecommendationModel:
    def __init__(self):
        self.recipe_df = None
        self.vectorizer = None
        self.model = None
        self.ingredients_vectors = None
        self.ing_embeddings = None
        self.stopset = stopwords.words('english') + list(string.punctuation)
        self.wl = WordNetLemmatizer()
        self.logger = logging.getLogger(__name__)

    async def preprocess_text(self, text: str) -> str:
        try:
            text = unidecode(text)
            text = re.sub(r'[^\w\s]', '', text)
            text = re.sub(r'\d', '', text)
            word_lst = []
            words = text.split(" ")
            for word in words:
                word = word.lower()
                word = self.wl.lemmatize(word)
                if word not in self.stopset:
                    word_lst.append(word)
            word_str = " ".join(word_lst)
            return word_str
        except Exception as e:
            self.logger.error(
                f"An error occurred while preprocess text: {e} | Line: {e.__traceback__.tb_lineno}")
            return ""

    async def preprocess_ingredients(self, ingredients: list) -> str:
        try:
            ingredient_list = []
            for ing in ingredients:
                ingredient_list.append(ing['ingredient'])

            return " ".join(ingredient_list)
        except Exception as e:
            self.logger.error(
                f"An error occurred while preprocess ingredients: {e} | Line: {e.__traceback__.tb_lineno}")
            return ""

    async def load_and_preprocess_data(self, recipe_collection: motor.motor_asyncio.AsyncIOMotorCollection) -> None:
        try:
            data = await recipe_collection.find().to_list(length=None)
            df = pd.DataFrame(data)
            recipe_df = df.copy()

            recipe_df['ingredients'] = await asyncio.gather(
                *(self.preprocess_ingredients(ing) for ing in recipe_df['ingredients']))
            recipe_df['recipe_name'] = recipe_df['recipe_name'].apply(lambda x: unidecode(x.lower()))
            recipe_df['cuisine_type'] = recipe_df['cuisine_type'].apply(
                lambda cuisine_type: " ".join([unidecode(name.lower()) for name in cuisine_type]))
            recipe_df['ideal_consumption'] = recipe_df['ideal_consumption'].apply(
                lambda ideal_consumption: " ".join([unidecode(name.lower()) for name in ideal_consumption]))
            recipe_df['difficulty_level'] = recipe_df['difficulty_level'].apply(
                lambda difficulty_level: " ".join([unidecode(name.lower()) for name in difficulty_level]))
            recipe_df['diet_type'] = recipe_df['diet_type'].apply(
                lambda diet_type: " ".join([unidecode(name.lower()) for name in diet_type]))
            recipe_df['recipe_intro'] = await asyncio.gather(
                *(self.preprocess_text(description) for description in recipe_df['recipe_intro']))

            recipe_df['combine'] = recipe_df['recipe_name'] + " " + recipe_df['ingredients'] + " " + \
                                   recipe_df['cuisine_type'] + " " + recipe_df['ideal_consumption'] + " " \
                                   + recipe_df['difficulty_level'] + " " + recipe_df['diet_type'] + " " \
                                   + recipe_df['recipe_intro']
            self.vectorizer = TfidfVectorizer()
            self.model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

            self.ingredients_vectors = self.vectorizer.fit_transform(recipe_df['combine'])
            self.ing_embeddings = self.model.encode(recipe_df['combine'], show_progress_bar=True)

            self.recipe_df = recipe_df
            self.logger.info("Data loaded and preprocessed successfully")
        except Exception as e:
            self.logger.error(
                f"An error occurred while loading and preprocessing the data: {e} | Line: {e.__traceback__.tb_lineno}")

    async def query_recommendations(self, q_list: list) -> numpy.ndarray:
        try:
            q_vectors = self.vectorizer.transform(q_list)
            q_embeddings = self.model.encode(q_list)

            v_similarity = cosine_similarity(q_vectors, self.ingredients_vectors)
            e_similarity = cosine_similarity(q_embeddings, self.ing_embeddings)

            v_max_similarity = np.amax(v_similarity, axis=0)
            e_max_similarity = np.amax(e_similarity, axis=0)

            q_recommendation = np.maximum(v_max_similarity, e_max_similarity)
            return q_recommendation
        except Exception as e:
            self.logger.error(
                f"An error occurred while querying recommendations: {e} | Line: {e.__traceback__.tb_lineno}")
            return np.array([])

    async def recommend_recipes(self, user_queries: list, favorite_recipes: list, liked_recipes: list, disliked_recipes: list, alergie_recipe: list,
                                n: int) -> list:
        try:

            lists = [user_queries, favorite_recipes, liked_recipes]

            non_empty_list = [lst for lst in lists if len(lst) > 0]
            rec_data = liked_recipes + favorite_recipes + user_queries
            if len(non_empty_list) == 0:
                random_recipe = self.recipe_df['_id'].sample(n=n)
                return list(random_recipe.astype(str))
            else:
                self.recipe_df['final_score'] = await self.query_recommendations(rec_data)

            # Sort the recipes based on the comprehensive score
            sorted_recipes = self.recipe_df.sort_values('final_score', ascending=False)

            sorted_recipes = sorted_recipes[['recipe_name', '_id']].values

            object_ids = sorted_recipes[:, 1]
            recipe_name = sorted_recipes[:, 0]
            # get alergie recipe_name from alergie list.
            if alergie_recipe:
                alergie_vector = self.vectorizer.transform(alergie_recipe)
                alergie_similarity = cosine_similarity(alergie_vector, self.ingredients_vectors)
                alergie_max_similarity = np.amax(alergie_similarity, axis=0)
                alergie_max_index = np.where(alergie_max_similarity > 0)
                alergie_recipes = self.recipe_df['recipe_name'].iloc[alergie_max_index]
            else:
                alergie_recipes = []

            if favorite_recipes:
                self.recipe_df['fav_score'] = await self.query_recommendations(favorite_recipes)
                favorite_recipes = self.recipe_df.nlargest(len(favorite_recipes), 'fav_score')['recipe_name'].to_list()
            else:
                favorite_recipes = []

            mask = np.logical_not(
                np.logical_or(
                    np.isin(recipe_name, user_queries),
                    np.logical_or(
                        np.isin(recipe_name, favorite_recipes),
                        np.logical_or(
                            np.isin(recipe_name, disliked_recipes),
                            np.isin(recipe_name, alergie_recipes)
                        )
                    )
                )
            )
            filtered_array = sorted_recipes[mask][:, 1]
            recommanded_id = [str(id) for id in filtered_array]
            return recommanded_id[:n]
        except Exception as e:
            self.logger.error(f"An error occurred while recommending recipes: {e} | Line: {e.__traceback__.tb_lineno}")
            return []

    async def get_recommendations(self, fav_collection: motor.motor_asyncio.AsyncIOMotorCollection, recipe_collection: motor.motor_asyncio.AsyncIOMotorCollection, user_id: str, n: int) -> list:
        try:
            user = await fav_collection.find_one({'user_id': user_id},
                                                 {'_id': 0, 'updated_at': 0, 'created_at': 0})
            fav_list = []
            liked_list = []
            disliked_list = []
            alergie_list = []
            search_list = []
            search_order_list = []

            if user:
                for recipe in ['favourite_recipe', 'liked_recipe', 'dislikes_recipe']:
                    if recipe in user.keys():
                        recipe_recipe_name = recipe_collection.find(
                            {'_id': {'$in': [ObjectId(x) for x in user[recipe]]}}, {'_id': 0, 'recipe_name': 1})
                        if recipe == 'favourite_recipe':
                            # fav_list = [item async for recipe_name in recipe_recipe_name for item in recipe_name.values()]
                            ids = [ObjectId(id) for id in user[recipe]]
                            fav_list = self.recipe_df['combine'][self.recipe_df['_id'].isin(ids)].to_list()
                        elif recipe == 'liked_recipe':
                            # liked_list = [item async for recipe_name in recipe_recipe_name for item in  recipe_name.values()]
                            ids = [ObjectId(id) for id in user[recipe]]
                            liked_list = self.recipe_df['combine'][self.recipe_df['_id'].isin(ids)].to_list()
                        elif recipe == 'disliked_recipe':
                            disliked_list = [item async for recipe_name in recipe_recipe_name for item in
                                             recipe_name.values()]

                for recipe in ['search_recipe', 'alergie_recipe', 'search_order_recipe']:
                    if recipe in user.keys():
                        if recipe == 'search_recipe':
                            search_list = [word for word in user['search_recipe'] if word is not None]
                        elif recipe == 'alergie_recipe':
                            alergie_list = user['alergie_recipe']
                        elif recipe == 'search_order_recipe':
                            search_order_list = [word for word in user['search_order_recipe'] if word is not None]

                search_list = search_list + search_order_list
                re_list = await self.recommend_recipes(search_list, fav_list, liked_list, disliked_list, alergie_list,
                                                       n)
                return re_list
            else:
                random_recipe = self.recipe_df['_id'].sample(n=n)
                return list(random_recipe.astype(str))

        except Exception as e:
            self.logger.error(
                f"An error occurred while getting recommendations for user {user_id}: {e} | Line: {e.__traceback__.tb_lineno}")
            return []


# In[10]:


if __name__ == "__main__":
    async def fetch_data(collection):
        from motor.motor_asyncio import AsyncIOMotorClient

        mongo_db_uri = "mongodb+srv://coretus:3zy6W0V157a9s4rh@development-db-16686332.mongo.ondigitalocean.com" \
                       "/?authSource=admin"
        mongo_client = AsyncIOMotorClient(mongo_db_uri)
        mongo_db = mongo_client['Eat']
        collection = mongo_db[collection]
        return collection


    async def main():
        recipe_collection = await fetch_data('recipe_data')
        fav_collection = await fetch_data('favourite')
        recommendation_model = RecipeRecommendationModel()
        await recommendation_model.load_and_preprocess_data(recipe_collection)
        return await recommendation_model.get_recommendations(fav_collection, recipe_collection,
                                                              "651659f1d8ff3a03b70476b6", 10)


    print(asyncio.run(main()))

# In[ ]:


# In[ ]:


# In[ ]:
