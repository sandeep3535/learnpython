from pydantic import BaseModel


class SimilarCocktailSchema(BaseModel):
    cocktail_id: str = ""
    n: int = 4
    similar_cocktails: list = []

    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "cocktail_id": "64a6b634687326839c0d2fa2",
                "n": 4,
            }
        }
