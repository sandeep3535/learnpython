from pydantic import BaseModel


class CocktailfoodSchema(BaseModel):
    cocktail_id: str = ""
    n: int = 4
    cocktailfoodpair: list = []

    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "cocktail_id": "649d6943c154586db706146f",
                "n": 4,
            }
        }

