from bson import ObjectId
from pydantic import BaseModel, EmailStr


class WineRecommendationSchema(BaseModel):
    user_id: str = ""
    n: int = 4
    wine_recommendation: list = []

    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "user_id": "64ca602aa0f0fd271100dd42",
                "n": 4,
            }
        }

