from pydantic import BaseModel


class RecipeRecommendationSchemas(BaseModel):
    user_id: str = ""
    n: int = 4
    foodrecommendations: list = []

    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "user_id": "64ca602aa0f0fd271100dd42",
                "n": 4,
            }
        }
