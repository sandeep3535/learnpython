from pydantic import BaseModel


class WinepairSchema(BaseModel):
    recipe_id: str = ""
    n: int = 4
    winepair: list = []

    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "recipe_id": "646305715d83a5b35058a2e8",
                "n": 4,
            }
        }

