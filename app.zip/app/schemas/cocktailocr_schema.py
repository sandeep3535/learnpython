from pydantic import BaseModel


class CocktailOcrSchema(BaseModel):
    cocktail: str = None
    ingradient: str = None
    suggested_cocktail: dict = {}

    class Config:
        schema_extra = {
            "example": {
                "cocktail": "",
                "ingradient": ""
            }
        }
