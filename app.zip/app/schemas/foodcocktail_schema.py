from pydantic import BaseModel


class FoodcocktailSchema(BaseModel):
    recipe_id: str = ""
    n: int = 4
    foodcocktailpair: list = []

    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "recipe_id": "651176ac5cdb3fc5a56d57d6",
                "n": 4,
            }
        }

