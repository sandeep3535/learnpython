from pydantic import BaseModel


class CocktailRecipeSchema(BaseModel):
    item_per_page: int = 0
    current_page: int = 0
    ingradients: str = None
    search: str = None

    class Config:
        schema_extra = {
            "example": {
                "item_per_page": 5,
                "current_page": 1,
                "ingradients": "",
                "search": ""
            }
        }
