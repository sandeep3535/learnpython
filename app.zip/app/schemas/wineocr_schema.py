from pydantic import BaseModel


class WineOcrSchema(BaseModel):
    wine: str = None
    type: str = None
    suggested_wine: list = []

    class Config:
        schema_extra = {
            "example": {
                "wine": "",
                "type": ""
            }
        }
