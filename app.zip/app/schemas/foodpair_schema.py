from pydantic import BaseModel


class FoodpairSchema(BaseModel):
    wine_id: str = ""
    n: int = 4
    foodpair: list = []

    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "wine_id": "648fdc769a6a48bf9d075c92",
                "n": 4,
            }
        }

