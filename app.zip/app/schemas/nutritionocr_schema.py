from pydantic import BaseModel


class NutritionOcr_schema(BaseModel):
    nutrition: str = None
    suggested_nutritions: dict = {}

    class Config:
        schema_extra = {
            "example": {
                "nutrition": "",
            }
        }