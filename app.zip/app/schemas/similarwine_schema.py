from pydantic import BaseModel


class SimilarWineSchema(BaseModel):
    wine_id: str = ""
    n: int = 4
    similar_wines: list = []

    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "wine_id": "64f6c2115fd3cdbd36595489",
                "n": 4,
            }
        }
