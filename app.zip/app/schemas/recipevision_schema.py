from pydantic import BaseModel


class RecipeVisionSchema(BaseModel):
    recipe: str = None
    ingradient: str = None
    suggested_recipe: dict = {}

    class Config:
        schema_extra = {
            "example": {
                "recipe": "",
                "ingradient": ""
            }
        }
